#!/usr/bin/env bash
#
# Flatpak Manager - installer
#
# Installs everything Flatpak Manager needs, adds it to your applications menu,
# and sets it up to handle Flathub "Install" buttons and .flatpakref files.
# Run it as your normal user (it asks for your password only when it needs to
# install system packages):
#
#     bash install.sh
#
# Options:
#     -y, --yes          answer "yes" to every question (no prompts). This includes
#                        accepting the license terms. Start at login is left as it is
#                        unless you also pass --autostart.
#         --autostart    start Flatpak Manager (quietly, in the tray) when you log in
#         --no-autostart don't start at login (and turn it off if it was on)
#         --no-deps      skip installing system packages (you installed them yourself)
#         --no-mime      don't make Flatpak Manager the handler for Flathub install links
#         --uninstall    remove Flatpak Manager (add --purge to also delete its settings)
#     -h, --help         show this help
#
# License: free to install and use, for personal and business purposes, on up to 6
# installations at the same time; more than that needs a paid license from the
# developer (https://classicgizmo.com/). Full terms: LICENSE.txt.
#
# Supported package managers: apt (Debian, Ubuntu, Linux Mint, Linux Lite, Pop!_OS...),
# dnf (Fedora), pacman (Arch, Manjaro), zypper (openSUSE).

[ -n "${BASH_VERSION:-}" ] || { echo "Please run this installer with bash:  bash install.sh" >&2; exit 1; }
set -u

VERSION="1.0.1"
APP_NAME="flatpak-manager"
FLATHUB_URL="https://dl.flathub.org/repo/flathub.flatpakrepo"
MIME_TYPES=(application/vnd.flatpak.ref application/vnd.flatpak x-scheme-handler/flatpak+https)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_APP="$SCRIPT_DIR/flatpak_manager.py"

ASSUME_YES=0
DO_DEPS=1
DO_MIME=1
DO_UNINSTALL=0
PURGE=0
ALLOW_ROOT=0          # only for containers/testing; the installer refuses to run as root otherwise
WARNINGS=()
PM=""
PIP_PKG=""
CORE_PKGS=()
EXTRA_PKGS=()
FLATPAK_NEWLY_INSTALLED=0
ADMIN_STATE=""        # "" = not asked yet, ok, or no
AUTOSTART=""          # "" = ask (or leave as is with --yes), yes, no

# ----------------------------------------------------------------------------- output helpers
if [ -t 1 ] && command -v tput >/dev/null 2>&1 && [ "$(tput colors 2>/dev/null || echo 0)" -ge 8 ]; then
    BOLD=$(tput bold); RED=$(tput setaf 1); GREEN=$(tput setaf 2); YELLOW=$(tput setaf 3); CYAN=$(tput setaf 6); RESET=$(tput sgr0)
else
    BOLD=""; RED=""; GREEN=""; YELLOW=""; CYAN=""; RESET=""
fi
case "${LC_ALL:-${LC_CTYPE:-${LANG:-}}}" in
    *[Uu][Tt][Ff]-8*|*[Uu][Tt][Ff]8*) TICK="✓"; CROSS="✗"; WARN="!" ;;
    *) TICK="+"; CROSS="x"; WARN="!" ;;
esac
step() { printf '\n%s[%s]%s %s%s%s\n' "$CYAN" "$1" "$RESET" "$BOLD" "$2" "$RESET"; }
ok()   { printf '  %s%s%s %s\n' "$GREEN" "$TICK" "$RESET" "$*"; }
info() { printf '    %s\n' "$*"; }
warn() { printf '  %s%s%s %s\n' "$YELLOW" "$WARN" "$RESET" "$*"; WARNINGS+=("$*"); }
err()  { printf '  %s%s%s %s\n' "$RED" "$CROSS" "$RESET" "$*" >&2; }
die()  { err "$*"; exit 1; }

# ask "question" [Y|N]  - returns 0 for yes. With --yes (or no terminal) the default is taken.
ask() {
    local question="$1" default="${2:-Y}" reply hint="[Y/n]"
    [ "$default" = "N" ] && hint="[y/N]"
    if [ "$ASSUME_YES" = 1 ]; then [ "$default" = "Y" ]; return; fi
    read -r -p "  $question $hint " reply || reply=""
    case "${reply:-$default}" in [Yy]*) return 0 ;; *) return 1 ;; esac
}

usage() { awk 'NR==1{next} /^#/{sub(/^# ?/,""); print; next} {exit}' "${BASH_SOURCE[0]}"; }

# ----------------------------------------------------------------------------- locations
set_paths() {
    : "${HOME:?HOME is not set}"
    DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
    CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
    APP_DIR="$DATA_HOME/$APP_NAME"
    LIB_DIR="$APP_DIR/lib"
    APP_FILE="$APP_DIR/flatpak_manager.py"
    BIN_DIR="$HOME/.local/bin"
    LAUNCHER="$BIN_DIR/$APP_NAME"
    APPS_DIR="$DATA_HOME/applications"
    DESKTOP_FILE="$APPS_DIR/$APP_NAME.desktop"
    SETTINGS_FILE="$HOME/.flatpak_manager_settings.json"
    AUTOSTART_FILE="$CONFIG_HOME/autostart/$APP_NAME.desktop"
}

# ----------------------------------------------------------------------------- quoting helpers
# Quote a string for a POSIX shell.
sh_quote() { local s=$1; printf "'%s'" "${s//\'/\'\\\'\'}"; }

# Quote a path for the Exec= line of a .desktop file (freedesktop Desktop Entry spec).
desktop_exec_quote() {
    local s=$1
    case $s in
        *[!A-Za-z0-9_./+:@%-]*)
            s=${s//\\/\\\\\\\\}
            s=${s//\"/\\\\\"}
            s=${s//\`/\\\\\`}
            s=${s//\$/\\\\\$}
            printf '"%s"' "$s" ;;
        *) printf '%s' "$s" ;;
    esac
}

# ----------------------------------------------------------------------------- system helpers
run_root() {
    if [ "$(id -u)" -eq 0 ]; then "$@"
    elif command -v sudo >/dev/null 2>&1; then sudo "$@"
    else err "Administrator access (sudo) isn't available, so I can't run: $*"; return 127
    fi
}

# Asks for administrator rights once, up front, so a cancelled or failed password
# never turns into a string of repeated prompts.
ensure_admin() {
    [ "$ADMIN_STATE" = ok ] && return 0
    [ "$ADMIN_STATE" = no ] && return 1
    if [ "$(id -u)" -eq 0 ]; then ADMIN_STATE=ok
    elif command -v sudo >/dev/null 2>&1 && sudo -v; then ADMIN_STATE=ok
    else ADMIN_STATE=no
    fi
    [ "$ADMIN_STATE" = ok ]
}

detect_pkg_manager() {
    local pm
    for pm in apt-get dnf pacman zypper; do
        if command -v "$pm" >/dev/null 2>&1; then PM="$pm"; return 0; fi
    done
    PM=""
}

distro_name() {
    # shellcheck source=/dev/null
    ( . /etc/os-release 2>/dev/null && printf '%s' "${PRETTY_NAME:-${NAME:-Linux}}" ) || printf 'Linux'
}

pkg_installed() {
    case "$PM" in
        apt-get) dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed" ;;
        dnf|zypper) rpm -q "$1" >/dev/null 2>&1 ;;
        pacman) pacman -Qi "$1" >/dev/null 2>&1 ;;
        *) return 1 ;;
    esac
}

# pm_install [--no-recommends] pkg...
pm_install() {
    local norec=0
    if [ "${1:-}" = "--no-recommends" ]; then norec=1; shift; fi
    case "$PM" in
        apt-get)
            if [ "$norec" = 1 ]; then run_root env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "$@"
            else run_root env DEBIAN_FRONTEND=noninteractive apt-get install -y "$@"; fi ;;
        dnf) run_root dnf install -y "$@" ;;
        pacman) run_root pacman -S --needed --noconfirm "$@" ;;
        zypper) run_root zypper --non-interactive install "$@" ;;
        *) return 1 ;;
    esac
}

apt_has() { apt-cache show "$1" >/dev/null 2>&1; }

# First candidate package that exists in the repositories.
apt_pick() { local p; for p in "$@"; do if apt_has "$p"; then printf '%s' "$p"; return 0; fi; done; return 1; }

plan_packages() {
    CORE_PKGS=(); EXTRA_PKGS=(); PIP_PKG=""
    case "$PM" in
        apt-get)
            # python3-pystray pulls in the GTK typelib, AppIndicator, python3-gi, Pillow, six and xlib.
            CORE_PKGS=(python3 python3-tk python3-pil flatpak)
            if apt_has python3-pystray; then
                CORE_PKGS+=(python3-pystray)
            else
                local ind; ind=$(apt_pick gir1.2-ayatanaappindicator3-0.1 gir1.2-appindicator3-0.1) || ind=""
                CORE_PKGS+=(python3-gi gir1.2-gtk-3.0)
                [ -n "$ind" ] && CORE_PKGS+=("$ind")
            fi
            PIP_PKG="python3-pip"
            EXTRA_PKGS=(xdg-utils desktop-file-utils pulseaudio-utils sound-theme-freedesktop) ;;
        dnf)
            CORE_PKGS=(python3 python3-tkinter python3-pillow python3-gobject gtk3 libayatana-appindicator-gtk3 flatpak)
            PIP_PKG="python3-pip"
            EXTRA_PKGS=(xdg-utils desktop-file-utils pulseaudio-utils sound-theme-freedesktop) ;;
        pacman)
            CORE_PKGS=(python tk python-pillow python-gobject gtk3 libayatana-appindicator flatpak)
            PIP_PKG="python-pip"
            EXTRA_PKGS=(xdg-utils desktop-file-utils libpulse sound-theme-freedesktop) ;;
        zypper)
            CORE_PKGS=(python3 python3-tk python3-Pillow python3-gobject typelib-1_0-Gtk-3_0 typelib-1_0-AyatanaAppIndicator3-0_1 flatpak)
            PIP_PKG="python3-pip"
            EXTRA_PKGS=(xdg-utils desktop-file-utils pulseaudio-utils sound-theme-freedesktop) ;;
    esac
}

# Prints the modules (from the arguments) that Python cannot find.
py_missing_modules() {
    PYTHONPATH="$LIB_DIR${PYTHONPATH:+:$PYTHONPATH}" python3 - "$@" <<'PYEOF'
import importlib.util, sys
print(" ".join(m for m in sys.argv[1:] if importlib.util.find_spec(m) is None))
PYEOF
}

# ----------------------------------------------------------------------------- steps
step_check_system() {
    step "1/7" "Checking your system"
    ok "$(distro_name)"
    detect_pkg_manager
    if [ -n "$PM" ]; then ok "Package manager: ${PM%-get}"
    else warn "No supported package manager found (apt, dnf, pacman or zypper) - system packages will be skipped."; DO_DEPS=0; fi
    if command -v python3 >/dev/null 2>&1; then
        if python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' 2>/dev/null; then
            ok "Python $(python3 -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])')"
        else
            warn "Python 3.8 or newer is required; found $(python3 --version 2>&1). Newer system packages will be installed if available."
        fi
    else
        info "Python 3 isn't installed yet - it will be installed below."
    fi
    if command -v flatpak >/dev/null 2>&1; then ok "Flatpak is installed"; else info "Flatpak isn't installed yet - it will be installed below."; fi
    [ -n "${XDG_CURRENT_DESKTOP:-}" ] && info "Desktop: $XDG_CURRENT_DESKTOP"
    return 0
}

step_system_packages() {
    step "2/7" "Installing required system packages"
    if [ "$DO_DEPS" != 1 ]; then info "Skipped (--no-deps)."; return 0; fi
    plan_packages
    local missing=() p
    for p in "${CORE_PKGS[@]}"; do pkg_installed "$p" || missing+=("$p"); done
    local extra_missing=()
    for p in "${EXTRA_PKGS[@]}"; do pkg_installed "$p" || extra_missing+=("$p"); done
    command -v flatpak >/dev/null 2>&1 || FLATPAK_NEWLY_INSTALLED=1

    if [ ${#missing[@]} -eq 0 ] && [ ${#extra_missing[@]} -eq 0 ]; then
        ok "Everything needed is already installed"; FLATPAK_NEWLY_INSTALLED=0; return 0
    fi
    if [ ${#missing[@]} -gt 0 ]; then
        info "Needed:   ${missing[*]}"
    fi
    if [ ${#extra_missing[@]} -gt 0 ]; then
        info "Optional: ${extra_missing[*]}  (sound alerts and menu/link registration)"
    fi
    info "This needs administrator rights, so you may be asked for your password."
    if ! ask "Install these now?" Y; then
        warn "Skipped installing system packages. Flatpak Manager may not start until they are installed."
        FLATPAK_NEWLY_INSTALLED=0
        return 0
    fi
    if ! ensure_admin; then
        warn "Couldn't get administrator rights, so no system packages were installed."
        info "Ask an administrator to install:  ${missing[*]}"
        info "or re-run this installer from an account that can use sudo."
        FLATPAK_NEWLY_INSTALLED=0
        return 0
    fi
    if [ "$PM" = "apt-get" ]; then
        run_root apt-get update >/dev/null 2>&1 || warn "Updating the package list reported a problem (often a third-party repository). Continuing."
        # Re-plan now that the package list is fresh (e.g. python3-pystray may only show up after an update).
        plan_packages
        missing=()
        for p in "${CORE_PKGS[@]}"; do pkg_installed "$p" || missing+=("$p"); done
    fi

    if [ ${#missing[@]} -gt 0 ]; then
        if pm_install "${missing[@]}"; then ok "Installed required packages"
        else
            warn "The combined install failed - trying each package on its own"
            local failed=()
            for p in "${missing[@]}"; do pm_install "$p" >/dev/null 2>&1 || failed+=("$p"); done
            if [ ${#failed[@]} -gt 0 ]; then
                warn "Couldn't install: ${failed[*]}  (the name may differ on your distribution - see README.md)"
            else ok "Installed required packages"; fi
        fi
    fi
    # Optional extras one by one so a missing name can never block the rest.
    for p in "${extra_missing[@]}"; do pm_install "$p" >/dev/null 2>&1 || info "(optional package '$p' not available - skipped)"; done
    command -v flatpak >/dev/null 2>&1 || FLATPAK_NEWLY_INSTALLED=0
    return 0
}

step_python_extras() {
    step "3/7" "Checking Python components"
    if ! command -v python3 >/dev/null 2>&1; then warn "Python 3 is missing, so nothing more can be checked here."; return 0; fi
    local mods; mods=$(py_missing_modules pystray six Xlib)
    if [ -z "$mods" ]; then ok "Tray icon support is available"; return 0; fi
    info "Your distribution doesn't provide: $mods - fetching them into your home folder (no admin rights needed)."
    local names=() m
    for m in $mods; do
        case "$m" in pystray) names+=(pystray) ;; six) names+=(six) ;; Xlib) names+=(python-xlib) ;; esac
    done
    if ! python3 -m pip --version >/dev/null 2>&1; then
        if [ "$DO_DEPS" = 1 ] && [ -n "$PIP_PKG" ] && ensure_admin; then
            info "Installing pip ($PIP_PKG) first..."
            pm_install --no-recommends "$PIP_PKG" >/dev/null 2>&1
        fi
    fi
    if ! python3 -m pip --version >/dev/null 2>&1; then
        warn "pip isn't available, so ${names[*]} couldn't be fetched. Install it with your package manager, or run:  pip install --user ${names[*]}"
        return 0
    fi
    mkdir -p "$LIB_DIR"
    # --target keeps these separate from system Python (and works on "externally managed" distros).
    # --no-deps because Pillow comes from the system package; only these tiny pure-Python parts are fetched.
    if python3 -m pip install --quiet --disable-pip-version-check --no-deps --target "$LIB_DIR" "${names[@]}" >/dev/null 2>&1; then
        ok "Installed ${names[*]}"
    else
        warn "Couldn't download ${names[*]} (are you online?). Try again, or run:  pip install --user ${names[*]}"
    fi
    return 0
}

step_install_files() {
    step "4/7" "Installing Flatpak Manager"
    [ -f "$SRC_APP" ] || die "flatpak_manager.py wasn't found next to install.sh. Run this from the folder you downloaded."
    mkdir -p "$APP_DIR" "$BIN_DIR" "$APPS_DIR" || die "Couldn't create the install folders."
    cp "$SRC_APP" "$APP_FILE" || die "Couldn't copy the program."
    chmod 644 "$APP_FILE"
    [ -f "$SCRIPT_DIR/LICENSE.txt" ] && cp "$SCRIPT_DIR/LICENSE.txt" "$APP_DIR/LICENSE.txt"
    ok "Program installed to $APP_DIR"

    {
        printf '#!/bin/sh\n'
        printf '# Flatpak Manager launcher - created by install.sh\n'
        printf 'exec python3 %s "$@"\n' "$(sh_quote "$APP_FILE")"
    } > "$LAUNCHER" || die "Couldn't create the launcher."
    chmod 755 "$LAUNCHER"
    ok "Launcher: $LAUNCHER"

    {
        printf '[Desktop Entry]\n'
        printf 'Type=Application\n'
        printf 'Name=Flatpak Manager\n'
        printf 'GenericName=Flatpak App Manager\n'
        printf 'Comment=Keep your Flatpak apps updated, installed and tidy\n'
        printf 'Exec=%s %%u\n' "$(desktop_exec_quote "$LAUNCHER")"
        printf 'Icon=system-software-install\n'
        printf 'Terminal=false\n'
        printf 'Categories=System;PackageManager;\n'
        printf 'Keywords=flatpak;flathub;updates;apps;software;\n'
        [ "$DO_MIME" = 1 ] && printf 'MimeType=%s;\n' "$(IFS=';'; printf '%s' "${MIME_TYPES[*]}")"
    } > "$DESKTOP_FILE" || die "Couldn't create the menu entry."
    chmod 644 "$DESKTOP_FILE"
    command -v desktop-file-validate >/dev/null 2>&1 && { desktop-file-validate "$DESKTOP_FILE" >/dev/null 2>&1 || warn "The menu entry didn't pass desktop-file-validate (it will probably still work)."; }
    command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS_DIR" >/dev/null 2>&1
    ok "Added to your applications menu (System > Flatpak Manager)"

    if [ "$DO_MIME" = 1 ]; then
        if command -v xdg-mime >/dev/null 2>&1; then
            mkdir -p "$CONFIG_HOME"
            if xdg-mime default "$APP_NAME.desktop" "${MIME_TYPES[@]}" >/dev/null 2>&1; then
                ok "Flathub \"Install\" buttons and .flatpakref files will open in Flatpak Manager"
                info "If your browser is a Flatpak, choose \"System Handler\" when it asks which app should open the link."
            else
                warn "Couldn't register Flatpak Manager for Flathub install links (xdg-mime failed)."
            fi
        else
            warn "xdg-mime isn't installed, so Flathub install links weren't registered. Install xdg-utils and run this again."
        fi
    fi
    return 0
}

step_autostart() {
    step "5/7" "Start at login (optional)"
    local decision="keep"
    case "$AUTOSTART" in
        yes) decision="yes" ;;
        no)  decision="no" ;;
        *)   if [ "$ASSUME_YES" = 1 ]; then decision="keep"       # never change login behaviour silently
             elif ask "Start Flatpak Manager automatically when you log in? (It runs quietly in the system tray.)" Y; then decision="yes"
             else decision="no"; fi ;;
    esac
    case "$decision" in
        yes)
            mkdir -p "$(dirname "$AUTOSTART_FILE")" || { warn "Couldn't create the autostart folder."; return 0; }
            {
                printf '[Desktop Entry]\n'
                printf 'Type=Application\n'
                printf 'Name=Flatpak Manager\n'
                printf 'Comment=Keeps your Flatpak apps updated (starts quietly in the system tray)\n'
                printf 'Exec=%s --background\n' "$(desktop_exec_quote "$LAUNCHER")"
                printf 'Icon=system-software-install\n'
                printf 'Terminal=false\n'
                printf 'StartupNotify=false\n'
                printf 'X-GNOME-Autostart-enabled=true\n'
                printf 'X-GNOME-Autostart-Delay=3\n'
            } > "$AUTOSTART_FILE" || { warn "Couldn't set up start at login."; return 0; }
            chmod 644 "$AUTOSTART_FILE"
            ok "Flatpak Manager will start quietly in the tray when you log in"
            ;;
        no)
            if [ -e "$AUTOSTART_FILE" ]; then rm -f "$AUTOSTART_FILE"; ok "Start at login is turned off"
            else info "Not starting at login."; fi
            info "You can change this any time: Preferences > Startup, or the tray menu."
            ;;
        *)
            if [ -e "$AUTOSTART_FILE" ]; then info "Start at login is already on (left as it was)."
            else info "Not starting at login. Turn it on any time: Preferences > Startup, or the tray menu."; fi
            ;;
    esac
    return 0
}

step_flathub() {
    step "6/7" "Setting up Flathub (the Flatpak app store)"
    if ! command -v flatpak >/dev/null 2>&1; then warn "Flatpak isn't installed, so Flathub couldn't be set up."; return 0; fi
    if flatpak remote-list 2>/dev/null | grep -qi 'flathub'; then ok "Flathub is already set up"; return 0; fi
    if [ "$DO_DEPS" != 1 ]; then info "Flathub isn't set up yet. Flatpak Manager will offer to add it the first time it starts."; return 0; fi
    info "Adding the Flathub repository (needs administrator rights)."
    if ! ensure_admin; then
        warn "No administrator rights, so Flathub wasn't added. Flatpak Manager will offer to add it the first time it starts."
        return 0
    fi
    if run_root flatpak remote-add --if-not-exists flathub "$FLATHUB_URL"; then ok "Flathub added"
    else warn "Couldn't add Flathub (are you online?). Flatpak Manager will offer to add it the first time it starts."; fi
    return 0
}

tray_tip() {
    local desk; desk=$(printf '%s' "${XDG_CURRENT_DESKTOP:-}:${DESKTOP_SESSION:-}" | tr '[:lower:]' '[:upper:]')
    case "$desk" in
        *XFCE*)   printf '%s' 'Right-click an empty spot on your panel > Panel > Panel Preferences > Items > + (Add) > "Status Tray Plugin".' ;;
        *KDE*|*PLASMA*) printf '%s' 'Right-click your panel > Add Widgets > "System Tray".' ;;
        *MATE*)   printf '%s' 'Right-click your panel > Add to Panel > "Notification Area".' ;;
        *CINNAMON*) printf '%s' 'Right-click your panel > Applets > turn on "System Tray".' ;;
        *LXQT*)   printf '%s' 'Right-click your panel > Manage Widgets > add "Status Notifier Plugin".' ;;
        *LXDE*)   printf '%s' 'Right-click your panel > Add / Remove Panel Items > add "Notification Area".' ;;
        *GNOME*|*UNITY*) printf '%s' 'GNOME hides tray icons by default - install the "AppIndicator and KStatusNotifierItem Support" extension.' ;;
        *)        printf '%s' 'Make sure your panel has a "system tray", "notification area" or "status notifier" item.' ;;
    esac
}

step_verify() {
    step "7/7" "Checking that it works"
    local out status
    out=$("$LAUNCHER" --check 2>&1); status=$?
    if [ $status -eq 0 ]; then
        ok "Flatpak Manager passed its self-check"
        printf '%s\n' "$out" | sed 's/^/      /'
    else
        err "Flatpak Manager can't start yet:"
        printf '%s\n' "$out" | sed 's/^/      /' >&2
        warn "Flatpak Manager failed its self-check - see the message above."
    fi
    return 0
}

print_summary() {
    printf '\n%s%s Done!%s Flatpak Manager %s is installed.\n' "$GREEN" "$TICK" "$RESET" "$VERSION"
    printf '\n  Open it from your applications menu (System > Flatpak Manager),\n'
    case ":$PATH:" in
        *":$BIN_DIR:"*) printf '  or type:  %s\n' "$APP_NAME" ;;
        *) printf '  or log out and back in, then type:  %s\n' "$APP_NAME" ;;
    esac
    printf '\n  %sSystem tray:%s the arrow icon (green = up to date, gold = updates waiting) shows in your\n' "$BOLD" "$RESET"
    printf '  panel'"'"'s tray. If you can'"'"'t see it, enable the tray on your panel:\n      %s\n' "$(tray_tip)"
    printf '  Flatpak Manager also checks this itself and will tell you if it can'"'"'t find a tray.\n'
    if pgrep -f 'flatpak_manager\.py' >/dev/null 2>&1; then
        printf '\n  %sFlatpak Manager is running right now:%s choose Quit from its tray icon, then open it again to use this version.\n' "$BOLD" "$RESET"
    fi
    if [ "$FLATPAK_NEWLY_INSTALLED" = 1 ]; then
        printf '\n  %sFlatpak was just installed:%s log out and back in (or restart) so Flatpak apps appear in your menu.\n' "$BOLD" "$RESET"
    fi
    if [ ${#WARNINGS[@]} -gt 0 ]; then
        printf '\n  %sThings to look at:%s\n' "$YELLOW" "$RESET"
        local w; for w in "${WARNINGS[@]}"; do printf '   - %s\n' "$w"; done
    fi
    printf '\n  License: free for up to 6 installations at the same time; more than that needs a paid license\n'
    printf '  (https://classicgizmo.com/). Full terms: Help & Info > EULA in the app.\n'
    printf '\n  To remove it later:  bash install.sh --uninstall\n\n'
}

# ----------------------------------------------------------------------------- uninstall
do_uninstall() {
    printf '\n%sRemoving Flatpak Manager%s\n' "$BOLD" "$RESET"
    if [ ! -e "$APP_DIR" ] && [ ! -e "$LAUNCHER" ] && [ ! -e "$DESKTOP_FILE" ]; then
        info "Flatpak Manager doesn't appear to be installed by this installer."
    fi
    # Stop a running copy first so it doesn't keep a stale tray icon.
    pkill -f "$APP_FILE" >/dev/null 2>&1 || true
    rm -rf "$APP_DIR" "$LAUNCHER" "$DESKTOP_FILE" "$AUTOSTART_FILE"
    ok "Removed the program, launcher, menu entry and start-at-login entry"
    command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS_DIR" >/dev/null 2>&1
    local f mimes='(application\/vnd\.flatpak(\.ref)?|x-scheme-handler\/flatpak\+https)'
    for f in "$CONFIG_HOME/mimeapps.list" "$APPS_DIR/mimeapps.list"; do
        [ -f "$f" ] || continue
        sed -i -E "/^$mimes=/ s/$APP_NAME\.desktop;?//g" "$f"
        sed -i -E "/^$mimes=;*[[:space:]]*\$/d" "$f"
    done
    ok "Flathub install links are no longer sent to Flatpak Manager"
    if [ "$PURGE" = 1 ]; then
        rm -f "$SETTINGS_FILE"; ok "Deleted your settings"
    elif [ -f "$SETTINGS_FILE" ]; then
        info "Your settings were kept ($SETTINGS_FILE). Use --uninstall --purge to delete them too."
    fi
    info "System packages (Python, Flatpak, etc.) were left alone because other programs may use them."
    printf '\n'
}

# ----------------------------------------------------------------------------- main
parse_args() {
    while [ $# -gt 0 ]; do
        case "$1" in
            -y|--yes) ASSUME_YES=1 ;;
            --no-deps) DO_DEPS=0 ;;
            --no-mime) DO_MIME=0 ;;
            --autostart) AUTOSTART=yes ;;
            --no-autostart) AUTOSTART=no ;;
            --uninstall) DO_UNINSTALL=1 ;;
            --purge) PURGE=1 ;;
            --allow-root) ALLOW_ROOT=1 ;;
            -h|--help) usage; exit 0 ;;
            *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
        esac
        shift
    done
}

main() {
    parse_args "$@"
    trap 'printf "\n"; err "Cancelled."; exit 130' INT
    [ -t 0 ] || ASSUME_YES=1          # nobody to ask (e.g. piped input) - take the defaults
    set_paths
    if [ "$(id -u)" -eq 0 ] && [ "$ALLOW_ROOT" != 1 ]; then
        err "Please run this as your normal user, not as root or with sudo."
        info "It installs Flatpak Manager into your own home folder and asks for your password only when it needs to."
        exit 1
    fi
    printf '%sFlatpak Manager %s - installer%s\n' "$BOLD" "$VERSION" "$RESET"
    if [ "$DO_UNINSTALL" = 1 ]; then do_uninstall; exit 0; fi
    printf '\nThis will install Flatpak Manager and anything it needs, and add it to your applications menu.\n'
    printf '\n%sLicense%s\n' "$BOLD" "$RESET"
    printf '  Flatpak Manager is free to install and use, for personal and business purposes,\n'
    printf '  on up to 6 installations at the same time. Using it on more than 6 at once needs\n'
    printf '  a paid license from the developer (https://classicgizmo.com/).\n'
    printf '  The full terms are in LICENSE.txt, and in the app under Help & Info > EULA.\n\n'
    ask "I accept the license terms. Continue?" Y || { printf '  Cancelled - nothing was changed.\n'; exit 0; }

    step_check_system
    step_system_packages
    step_python_extras
    step_install_files
    step_autostart
    step_flathub
    step_verify
    print_summary

    if [ -t 0 ] && [ "$ASSUME_YES" = 0 ] && { [ -n "${DISPLAY:-}" ] || [ -n "${WAYLAND_DISPLAY:-}" ]; }; then
        if ask "Open Flatpak Manager now?" Y; then nohup "$LAUNCHER" >/dev/null 2>&1 & disown 2>/dev/null; fi
    fi
}

# Run only when executed (lets the functions be tested by sourcing this file).
if [ "${BASH_SOURCE[0]}" = "$0" ]; then main "$@"; fi
