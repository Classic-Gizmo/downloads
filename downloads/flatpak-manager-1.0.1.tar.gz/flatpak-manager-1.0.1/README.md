# Flatpak Manager

A friendly desktop app and system-tray monitor for [Flatpak](https://flatpak.org). It watches your Flatpak apps and turns its tray arrow **gold** when updates are waiting. From one window you can update apps, find and install new ones from [Flathub](https://flathub.org), remove old ones, and run routine clean-up - no terminal needed.

**Version 1.0.1** - by [Classic Gizmo](https://classicgizmo.com) - Lead Developer: Patrick Murnane

**Free to install and use - for individuals and companies - on up to 6 installations at the same time.** Using it on more than 6 at once needs a paid license (see [Licensing](#licensing)).

## Install

1. Download Flatpak Manager (on GitHub: **Code > Download ZIP**) and extract it.
2. Open a terminal in that folder and run:

   ```
   bash install.sh
   ```

3. Read the short license notice and press Enter to accept the questions. You'll be asked for your password once, only so system packages (Python, Flatpak and so on) can be installed.
4. Say whether Flatpak Manager should start quietly in the tray when you log in.
5. Open **Flatpak Manager** from your applications menu (System section).

That's it. Run the same command again any time to update to a newer version - your settings are kept.

### What the installer does

- Installs what Flatpak Manager needs: Python's Tk and Pillow, the tray-icon library, and Flatpak itself if it's missing.
- Adds Flathub (the Flatpak app store) if it isn't set up yet.
- Installs the app into your home folder (`~/.local/share/flatpak-manager`) and adds a menu entry. Nothing is installed outside your home folder except the system packages above and the Flathub entry.
- Makes Flatpak Manager the handler for Flathub's **Install** buttons and for `.flatpakref` / `.flatpak` files (skip this with `--no-mime`).
- Asks whether to start Flatpak Manager at login (see [Start at login](#start-at-login)).
- Checks its own work at the end, and tells you plainly if anything needs attention.

It does **not** edit your panel or desktop settings (see the next section), and it only sets up start-at-login if you say yes.

Running `bash install.sh --yes` answers every question for you, which includes accepting the license terms. It leaves start-at-login as it was; add `--autostart` or `--no-autostart` to choose.

### Supported systems

| Distribution family | Package manager | Status |
|---|---|---|
| Debian, Ubuntu, Linux Mint, Linux Lite, Pop!_OS and relatives | `apt` | Installer tested end to end on Ubuntu 24.04 |
| Fedora and relatives | `dnf` | Supported, **not yet tested** on a real Fedora install |
| Arch, Manjaro, EndeavourOS | `pacman` | Supported, **not yet tested** on a real Arch install |
| openSUSE | `zypper` | Supported, **not yet tested** on a real openSUSE install |

Python 3.8 or newer is required. On the untested systems, if a package name turns out to differ, the installer tells you which one it couldn't install; install it by hand and re-run with `bash install.sh --no-deps`.

## Other ways to install

The installer above works on any distribution. If you'd rather use your system's own tools, Flatpak Manager is also available as an APT package and as a Flatpak. Pick **one** method - they're alternatives, not additions.

### With APT (Ubuntu, Linux Mint, Debian-based systems)

Run these three commands once:

```
curl -fsSL https://dl.classicgizmo.com/apt/classicgizmo-archive-keyring.gpg | sudo tee /usr/share/keyrings/classicgizmo-archive-keyring.gpg > /dev/null
echo "deb [signed-by=/usr/share/keyrings/classicgizmo-archive-keyring.gpg] https://dl.classicgizmo.com/apt stable main" | sudo tee /etc/apt/sources.list.d/classicgizmo.list
sudo apt update && sudo apt install flatpak-manager
```

After that it updates with the rest of your system (`sudo apt upgrade`). To remove it: `sudo apt remove flatpak-manager`. Your settings stay in your home folder.

This needs a distribution that provides `python3-pystray` (Ubuntu 24.04 and newer, and systems based on it). On older systems, use the installer above.

### As a Flatpak

```
flatpak install --user https://dl.classicgizmo.com/flatpak/com.classicgizmo.FlatpakManager.flatpakref
```

Or open that `.flatpakref` link in your browser or file manager. Updates then arrive like any other Flatpak.

Things to know about the Flatpak version:

- If this is the first Flatpak you have installed for your user, the menu entry may not appear until you log out and back in once.
- It manages the Flatpak apps on your computer, so it needs permission to run commands outside its sandbox (`flatpak-spawn --host`). It asks for this up front when you install it - that's the app's whole job.
- It keeps its own settings (in `~/.var/app/com.classicgizmo.FlatpakManager`), separate from an installer or APT copy.
- Start at login works the same way; the Preferences switch handles it.
- Don't install more than one version on the same computer: each would show its own tray arrow.

## Start at login

Flatpak Manager can start by itself when you log in, quietly and with no window, so the arrow is already in your tray and turns gold when updates arrive. Turn it on or off any time in any of these places:

- the installer's question (or `bash install.sh --autostart` / `--no-autostart`)
- **Preferences > Startup** in the app
- **Start at login** in the tray icon's menu

It works by adding a small file to `~/.config/autostart/`, which every major desktop reads. If your panel has no system tray at all, Flatpak Manager opens its window at login instead, so it is never running invisibly.

## The system tray icon

The arrow lives in your panel's **system tray** (near the clock). Some desktops don't show a tray until you add one, so if you don't see the arrow:

| Desktop | How to enable the tray |
|---|---|
| Xfce (including Linux Lite) | Right-click the panel > **Panel > Panel Preferences > Items**, click **+** and add **Status Tray Plugin** |
| KDE Plasma | Right-click the panel > **Add Widgets** > **System Tray** |
| MATE | Right-click the panel > **Add to Panel** > **Notification Area** |
| Cinnamon | Right-click the panel > **Applets** > turn on **System Tray** |
| LXQt | Right-click the panel > **Manage Widgets** > **Status Notifier Plugin** |
| LXDE | Right-click the panel > **Add / Remove Panel Items** > **Notification Area** |
| GNOME | GNOME hides tray icons by default. Install the **AppIndicator and KStatusNotifierItem Support** extension |

Menu names vary slightly between versions. Flatpak Manager also checks for a tray a few seconds after it starts and will tell you if it can't find one (you can silence that, and re-check any time from **Tools > Check System Tray**). Without a tray the app still works - you just open it from the menu instead.

## Installing from Flathub's website

After installing, clicking **Install** on a Flathub app page can open Flatpak Manager and ask you to confirm. Your browser will first ask which application should open the link. Choose **System Handler**, the entry that passes the link on to your desktop, and tick "Always use this application" if you like.

**If your browser is itself a Flatpak** (for example Firefox installed from Flathub) it is sandboxed and can't start programs from your home folder. Picking `flatpak-manager.desktop` from its list may then do nothing at all, so use **System Handler** instead.

Two other reliable routes: on the Flathub page use the **Download .flatpakref** link and double-click the downloaded file, or use **Manage Apps > Search & Install** / **Install from File** inside the app. Downloaded `.flatpakref` and `.flatpak` files open in Flatpak Manager from your file manager too.

## Installing without the installer

Install the packages for your distribution, then run `python3 flatpak_manager.py`:

| Distribution | Packages |
|---|---|
| Debian / Ubuntu family (tested) | `sudo apt install python3-tk python3-pil python3-pystray flatpak` |
| Fedora (untested) | `sudo dnf install python3-tkinter python3-pillow python3-gobject gtk3 libayatana-appindicator-gtk3 flatpak` |
| Arch (untested) | `sudo pacman -S tk python-pillow python-gobject gtk3 libayatana-appindicator flatpak` |
| openSUSE (untested) | `sudo zypper install python3-tk python3-Pillow python3-gobject typelib-1_0-Gtk-3_0 typelib-1_0-AyatanaAppIndicator3-0_1 flatpak` |

If your distribution has no `pystray` package, install it with `pip install --user pystray` (add `--break-system-packages` on distributions that block that).

Check that everything is in place with `python3 flatpak_manager.py --check`.

## Command line

```
flatpak-manager                  open the app
flatpak-manager --background     start quietly in the tray (this is what start-at-login runs)
flatpak-manager FILE.flatpakref  offer to install that file
flatpak-manager --check          verify that everything needed is installed
flatpak-manager --version
bash install.sh --uninstall      remove it (add --purge to also delete settings)
```

Only one copy runs at a time: starting it again just brings the existing window forward.

If a terminal says `flatpak-manager: command not found` straight after installing, that's only because your terminal hasn't picked up `~/.local/bin` yet. Log out and back in once, or run it by its full path: `~/.local/bin/flatpak-manager`. The menu entry works either way.

## Troubleshooting

- **Nothing happens when I open it from the menu.** Open a terminal and run `~/.local/bin/flatpak-manager`; any problem is printed. `~/.local/bin/flatpak-manager --check` lists what's missing.
- **The window opens but there's no arrow icon.** See *The system tray icon* above.
- **It says Flatpak or Flathub isn't set up.** Click the button in the dialog, or run `sudo flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo`. After Flatpak is installed for the very first time, log out and back in so Flatpak apps appear in your menu.
- **Start at login doesn't seem to work.** Check the switch in **Preferences > Startup**. Some desktops start login items a few seconds after the panel appears, so give it a moment.
- **Flathub's Install button does nothing.** If your browser is a Flatpak, choose **System Handler** in its dialog, not `flatpak-manager.desktop`. Otherwise re-run `bash install.sh` (without `--no-mime`) and restart your browser. Failing that, download the `.flatpakref` file from the Flathub page and double-click it. To test the app on its own, run `flatpak-manager "flatpak+https://dl.flathub.org/repo/appstream/APP.ID.flatpakref"` in a terminal.

Settings are saved in `~/.flatpak_manager_settings.json`.

## Licensing

Flatpak Manager is a **freemium** product. It is not open source: the code is readable, but copying, modifying and redistributing it isn't allowed.

- **Free** for personal and business use, for individuals and companies alike, on up to **6 installations at the same time**. An installation is one copy on one computer, physical or virtual. The 6 is counted across your whole organization, and removing an installation frees up a place for another.
- **More than 6 at once** needs a paid license from the developer. Current options and prices are on the website, [classicgizmo.com](https://classicgizmo.com/).

The full terms are in [`LICENSE.txt`](LICENSE.txt) and in the app under **Help & Info > EULA**. There's also a **Licensing & Pricing** button under **Help & Info**.

## Links

[GitHub](https://github.com/Classic-Gizmo) - [Website](https://classicgizmo.com/) - [Buy Me a Coffee](https://buymeacoffee.com/classicgizmo)

The End User License Agreement, upstream acknowledgements and credits are in the app under **Help & Info**.
