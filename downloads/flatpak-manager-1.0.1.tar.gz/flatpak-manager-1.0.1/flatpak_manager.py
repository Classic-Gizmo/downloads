# Flatpak Manager - Copyright (c) Classic Gizmo. All rights reserved.
# Free to install and use, for personal or business purposes, on up to 6
# installations at the same time. More than that needs a paid license from the
# developer. Full terms: LICENSE.txt, or Help & Info > EULA inside the app.
import os, json, subprocess, threading, time, re, webbrowser, shutil, sys, tempfile, urllib.request, urllib.parse
import socket, errno, fcntl, shlex, configparser
from concurrent.futures import ThreadPoolExecutor

APP_VERSION = "1.0.1"   # keep in step with the About text below
# Where the "Licensing & Pricing" button points. Change this to the pricing page once the website has one.
LICENSE_INFO_URL = "https://classicgizmo.com/"

# ---- Running inside a Flatpak sandbox ---------------------------------------------------------------
# The Flatpak build of this app cannot see the host's `flatpak` program, terminals or audio tools, and
# its /tmp, config folder and process list are private. Everything that has to reach the host goes
# through `flatpak-spawn --host` (this needs the org.freedesktop.Flatpak permission). Outside a
# sandbox none of this changes anything: host_argv() returns the command untouched.
IN_FLATPAK = os.path.exists("/.flatpak-info")
FLATPAK_APP_ID = os.environ.get("FLATPAK_ID") or "com.classicgizmo.FlatpakManager"

def host_argv(argv, gui=False):
    """The command line that runs `argv` on the host computer."""
    if not IN_FLATPAK:
        return list(argv)
    cmd = ["flatpak-spawn", "--host", "--directory=" + os.path.expanduser("~")]
    if gui:                                    # a terminal window needs to know which screen to open on
        for var in ("DISPLAY", "WAYLAND_DISPLAY"):
            if os.environ.get(var):
                cmd.append("--env=%s=%s" % (var, os.environ[var]))
    return cmd + list(argv)

_host_which_cache = {}
def host_which(binary):
    """Like shutil.which(), but looks on the host when running inside a Flatpak sandbox."""
    if not IN_FLATPAK:
        return shutil.which(binary)
    if binary not in _host_which_cache:
        found = None
        try:
            r = subprocess.run(host_argv(["sh", "-c", "command -v " + shlex.quote(binary)]), stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=10)
            if r.returncode == 0 and r.stdout.strip():
                found = r.stdout.strip().splitlines()[0]
        except (OSError, subprocess.SubprocessError):
            pass
        _host_which_cache[binary] = found
    return _host_which_cache[binary]

if IN_FLATPAK:
    # /tmp is private inside the sandbox, but $XDG_RUNTIME_DIR/app/<id> is the same folder on the host.
    # Using it for temp files lets host programs (the install terminal, the tray panel) read what we write.
    _runtime = os.environ.get("XDG_RUNTIME_DIR")
    _scratch = os.path.join(_runtime, "app", FLATPAK_APP_ID) if _runtime else None
    if _scratch and os.path.isdir(_scratch):
        tempfile.tempdir = _scratch

if "--version" in sys.argv[1:]:
    print("Flatpak Manager " + APP_VERSION); sys.exit(0)
if "--help" in sys.argv[1:] or "-h" in sys.argv[1:]:
    print("Flatpak Manager " + APP_VERSION + "\n\n"
          "Usage: flatpak_manager.py [FILE.flatpakref | FILE.flatpak | flatpak+https://...]\n"
          "       flatpak_manager.py --background verify nothing, just start quietly in the system tray (used at login)\n"
          "       flatpak_manager.py --check      verify that everything needed is installed\n"
          "       flatpak_manager.py --version")
    sys.exit(0)

# install.sh puts small pure-Python extras (pystray) here when the distribution
# doesn't package them. It is appended, so system packages always win.
_APP_LIB_DIR = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "flatpak-manager", "lib")
if os.path.isdir(_APP_LIB_DIR) and _APP_LIB_DIR not in sys.path:
    sys.path.append(_APP_LIB_DIR)

def _startup_dependency_error(missing, detail=""):
    """Explains a missing component in plain words, then exits. A double-clicked
    app has no terminal, so when stderr isn't a terminal this also tries to show
    a small dialog with whatever the desktop provides (zenity, kdialog, xmessage)."""
    lines = [
        "Flatpak Manager can't start yet - a required component is missing:",
        "    " + missing,
        "",
        "Easiest fix - run the installer that came with Flatpak Manager:",
        "    bash install.sh",
        "",
        "Or, on Debian / Ubuntu / Linux Mint / Linux Lite:",
        "    sudo apt install python3-tk python3-pil python3-pystray python3-gi gir1.2-gtk-3.0 gir1.2-ayatanaappindicator3-0.1",
        "",
        "Other distributions: see README.md for the package names.",
    ]
    if detail:
        lines += ["", "Technical detail: " + detail]
    text = "\n".join(lines)
    print(text, file=sys.stderr)
    quiet = "--check" in sys.argv
    if not quiet and not sys.stderr.isatty():
        for cmd in (["zenity", "--error", "--no-markup", "--title", "Flatpak Manager", "--text", text],
                    ["kdialog", "--title", "Flatpak Manager", "--error", text],
                    ["xmessage", "-center", "-title", "Flatpak Manager", text]):
            if shutil.which(cmd[0]):
                try:
                    subprocess.run(cmd, timeout=600)
                    break
                except Exception:
                    pass
    sys.exit(1)

try:
    import tkinter as tk
    import tkinter.font as tkfont
    from tkinter import messagebox, ttk, filedialog
except ImportError as _e:
    _startup_dependency_error("Tk for Python (package: python3-tk)", str(_e))
try:
    from PIL import Image, ImageDraw
except ImportError as _e:
    _startup_dependency_error("Pillow (package: python3-pil)", str(_e))

def _import_pystray():
    """pystray picks a tray backend itself, but only falls back to the next one on
    ImportError. A machine with Python's GTK bindings but no GTK typelib raises
    ValueError instead and would crash even though the classic backend works.
    So try the automatic choice first, then each backend explicitly."""
    last_err = None
    for backend in (None, "gtk", "xorg"):
        if backend is not None:
            for name in [m for m in sys.modules if m == "pystray" or m.startswith("pystray.")]:
                del sys.modules[name]
            os.environ["PYSTRAY_BACKEND"] = backend
        try:
            import pystray as _p
            return _p
        except Exception as e:
            last_err = e
    raise last_err

pystray = None
# Loading the tray library starts GTK, which tries to reach the desktop's accessibility service and prints a
# harmless but alarming "dbind-WARNING ... Permission denied" when that isn't reachable. Switch the bridge off
# only while it loads, then restore the variable so terminals this app opens later aren't affected.
_prev_at_bridge = os.environ.get("NO_AT_BRIDGE")
os.environ.setdefault("NO_AT_BRIDGE", "1")
try:
    pystray = _import_pystray()
except Exception as _e:
    _detail = "%s: %s" % (type(_e).__name__, _e)
    _no_display = not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY")
    if _no_display:
        _detail += "  (no graphical display detected - run this inside your desktop session)"
    import importlib.util as _ilu
    if not ("--check" in sys.argv and _no_display and _ilu.find_spec("Xlib") is not None):
        if isinstance(_e, ModuleNotFoundError) and getattr(_e, "name", "") == "pystray":
            _startup_dependency_error("the tray-icon library \"pystray\" (package: python3-pystray, or: pip install pystray)", _detail)
        _startup_dependency_error("system tray support (packages: python3-pystray, python3-gi, gir1.2-gtk-3.0, gir1.2-ayatanaappindicator3-0.1)", _detail)

if _prev_at_bridge is None:
    os.environ.pop("NO_AT_BRIDGE", None)

if IN_FLATPAK:
    _cfg_home = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.var/app/%s/config" % FLATPAK_APP_ID)
    try: os.makedirs(os.path.join(_cfg_home, "flatpak-manager"), exist_ok=True)
    except OSError: pass
    SETTINGS_FILE = os.path.join(_cfg_home, "flatpak-manager", "settings.json")
    LEGACY_SETTINGS_FILE = os.path.join(_cfg_home, "flatpak-manager", "settings.legacy.json")   # nothing to migrate inside the sandbox
else:
    SETTINGS_FILE = os.path.expanduser("~/.flatpak_manager_settings.json")
    LEGACY_SETTINGS_FILE = os.path.expanduser("~/.warehouse_settings.json")

LEGAL_DATA = {
    "eula": """END USER LICENSE AGREEMENT (EULA)
--------------------------------------
Flatpak Manager v1.0.1
Please read this agreement carefully before using Flatpak Manager.

1. ACCEPTANCE OF TERMS
By installing or using Flatpak Manager (the "Software") you agree to be bound by this agreement. If you do not agree, do not install or use the Software. If you accept on behalf of a company or other organization, you confirm that you have the authority to bind it.

2. FREE USE - UP TO 6 INSTALLATIONS
Classic Gizmo (the "Developer") grants you a free, non-exclusive, non-transferable license to install and use the Software, for personal or business purposes, on up to six (6) Installations at the same time.
• An "Installation" is one copy of the Software installed on one computer, physical or virtual.
• The limit of six applies to you or your organization as a whole, counting every Installation that you or your organization (including its subsidiaries and affiliates) have at the same time. Individuals and companies are treated alike.
• "At the same time" means installed and available for use at the same moment. Removing an Installation frees up a place for another one.
• You are responsible for keeping track of how many Installations you have.

3. LICENSE FEE FOR MORE THAN 6 INSTALLATIONS
To use the Software on more than six (6) Installations at the same time you must first obtain a paid license from the Developer. Current license options, prices and how to buy are published on the Developer's website (https://classicgizmo.com/) and may change from time to time. A paid license takes effect from the date it is granted. Using more than ten Installations at the same time without a paid license is a breach of this agreement.

4. RESTRICTIONS
You may not: (a) sell, rent, lease, sublicense or otherwise commercially exploit the Software; (b) give copies of the Software to people or organizations outside your own - point them to the Developer's official download instead (installing it on your own computers, within the limit above, is fine); (c) modify the Software, create works based on it, or share a modified version; (d) remove or change copyright, license or attribution notices; or (e) try to get around any limit or licensing requirement in this agreement.
The Software is supplied as readable script files. That does not make it open source: the Developer keeps all rights that are not expressly granted here.

5. OWNERSHIP
The Software is owned by the Developer and protected by copyright and other laws. This agreement gives you a license to use the Software; it does not transfer ownership of it.

6. THIRD-PARTY SOFTWARE
The Software works with, and depends on, software that belongs to others - including Flatpak, Flathub and the open-source components listed under Upstream Acknowledgements. That software is licensed under its own terms, which continue to apply to it, and nothing in this agreement limits your rights under them. Apps you install, update or remove using the Software come from their own publishers and are subject to their own terms; the Developer is not responsible for them.

7. PRIVACY
The Software does not collect or send personal information to the Developer. It runs Flatpak commands on your computer, and those commands contact Flathub and any other Flatpak repositories you have set up.

8. SYSTEM INTERACTIONS
This utility executes native system flatpak maintenance commands on your behalf. Ensure your internet connection is stable when running larger installation routines.

9. CHANGES TO THIS AGREEMENT
The Developer may update the Software and may change this agreement for new versions. The terms that apply to a version are the ones shown in that version (Help & Info > EULA). Continuing to use a new version means you accept the terms shown in it.

10. DISCLAIMER OF WARRANTY
THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT. Nothing in this agreement excludes, restricts or modifies any right or remedy you have under any law that cannot lawfully be excluded, restricted or modified.

11. LIMITATION OF LIABILITY
TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL THE DEVELOPER BE LIABLE FOR ANY CLAIM, DAMAGES, LOSS OF DATA, PROFITS OR BUSINESS, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

12. TERMINATION
This license ends automatically if you breach this agreement. When it ends you must stop using the Software and delete all copies of it. You can end it at any time by uninstalling the Software.

--------------------------------------
Questions about licensing: https://classicgizmo.com/
Thank you for using Flatpak Manager by Classic Gizmo!""",

    "upstream": """UPSTREAM ACKNOWLEDGEMENTS & GRATITUDE
--------------------------------------
We want to extend our deepest appreciation and respect to the exceptional core upstream projects that supply the essential engineering foundation for this software:

• Flatpak, the application distribution system this tool manages
• The Flathub app store and its distribution services
• The PyStray Linux System Tray Backend AppIndicator Wrapper
• The Pillow Graphics Rendering Asset Engine Library
• The Python Tkinter Desktop User Interface Toolkit
• python-xlib and PyGObject, used for system tray integration

These projects are open-source software released under their own licenses, which continue to apply to them. Flatpak Manager itself is not open source - it is a freemium product (see the EULA).

Without their world-class engineering, dedication, and open-source contributions, this system utility tool would not be possible. Thank you!""",

    "help": """USER HELP GUIDE & OPERATION GUIDE
--------------------------------------
Welcome to the Flatpak Manager workspace! Here is how to navigate your tool:

• MONITOR TAB: Displays your active tracked desktop programs. Apps with an update waiting glow gold, carry an ✨ [UPDATE] tag and float to the top (everything else is listed A-Z), and the header counts them. Click an app - or Ctrl-click / Shift-click several - and hit the Update button to update them all together in one go. 'Stop Tracking Target' hides the selected apps (and silences their update alerts) until you click Restore Hidden Apps. Manual Scan Now only looks for newly installed apps and waiting updates - it never changes which apps are hidden.
• MANAGE APPS TAB: Allows you to search Flathub and safely download brand-new applications. It also features a system utility ledger (listed A-Z) to completely uninstall obsolete software packages.
• PREFERENCES TAB: Features simple toggle switches to configure automated scanning sweeps, plus Start at Login, Dark Mode, Font Size, and optional Sound Notifications (off by default) that chime when a new app update is found.
• TOOLS TAB: Includes a Diagnostics & Testing section to safely verify the update-notification system (and check that your system tray is showing the arrow icon), and a Flatpak Maintenance section with one-click buttons for common upkeep tasks like removing unused runtimes and repairing your installation.
• LICENSE: Flatpak Manager is free for personal and business use on up to 6 installations at the same time. Using more than that needs a paid license. See the Licensing & Pricing button under Help & Info, or the EULA.

Tip: If a terminal installation freezes, check your active internet connection stability.""",

    "about": """ABOUT FLATPAK MANAGER
--------------------------------------
Flatpak Manager v1.0.1
Release Date: October 2026

A lightweight, high-performance system tray orchestration client crafted explicitly for desktop Linux distributions. 

Designed to simplify application lifecycle maintenance, optimize software storage configurations, and provide automated package upgrade checks via a fast background daemon framework.

LICENSE
--------------------------------------
Flatpak Manager is a freemium product. It is free to install and use, for personal and business purposes, on up to 6 installations at the same time. Using it on more than 6 installations at once needs a paid license from the developer. Current options and pricing are on the website (classicgizmo.com). Full terms are in the End User License Agreement (EULA).

DEVELOPER CREDITS
--------------------------------------
• Lead Developer: Patrick Murnane
• App by Classic Gizmo

Special gratitude to the open-source community for making desktop utility innovation seamless and accessible to users everywhere."""
}

DEFAULT_SETTINGS = {
    "apps": {},
    "auto_scan_enabled": True, "scan_intervals": ["On boot"], "last_scan_time": 0.0, "eula_accepted": False, "dark_mode": False, "font_scale": 0, "sounds_enabled": False, "tray_hint_dismissed": False, "hidden_apps": []
}
FONT_ROLE_SPECS = {
    "body9": {"family": "Helvetica", "size": 9},
    "body10": {"family": "Helvetica", "size": 10},
    "bold9": {"family": "Helvetica", "size": 9, "weight": "bold"},
    "bold10": {"family": "Helvetica", "size": 10, "weight": "bold"},
    "bold11": {"family": "Helvetica", "size": 11, "weight": "bold"},
    "italic9": {"family": "Helvetica", "size": 9, "slant": "italic"},
    "mono10": {"family": "Courier", "size": 10},
}
TK_NAMED_FONTS = ["TkDefaultFont", "TkTextFont", "TkHeadingFont", "TkMenuFont", "TkFixedFont", "TkCaptionFont", "TkSmallCaptionFont", "TkIconFont", "TkTooltipFont"]
# The app's gold: the tray arrow and the notification banner use this same colour (#ffe082).
UPDATE_GOLD = "#ffe082"
UPDATE_GOLD_TEXT = "#1c1c1e"
UPDATE_GOLD_SELECTED = "#ffc107"      # a deeper gold so a selected update row still stands out from an unselected one
THEME_COLORS = {
    "light": {"bg": "#ececec", "fg": "#000000", "widget_bg": "#ffffff", "select_bg": "#cce8ff", "secondary_fg": "#555555"},
    "dark":  {"bg": "#2b2b2b", "fg": "#e8e8e8", "widget_bg": "#3c3c3c", "select_bg": "#505050", "secondary_fg": "#b5b5b5"}
}
def load_settings():
    if not os.path.exists(SETTINGS_FILE) and os.path.exists(LEGACY_SETTINGS_FILE):
        try:
            shutil.copy2(LEGACY_SETTINGS_FILE, SETTINGS_FILE)
        except Exception:
            pass
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r") as f:
                d = json.load(f)
                d.setdefault("scan_intervals", ["On boot"])
                d.setdefault("last_scan_time", 0.0)
                d.setdefault("eula_accepted", False)
                d.setdefault("dark_mode", False)
                d.setdefault("font_scale", 0)
                d.setdefault("sounds_enabled", False)
                d.setdefault("tray_hint_dismissed", False)
                _hidden = d.get("hidden_apps")
                d["hidden_apps"] = [x for x in _hidden if isinstance(x, str)] if isinstance(_hidden, list) else []
                if not isinstance(d.get("apps"), dict): d["apps"] = {}
                if os.path.exists(LEGACY_SETTINGS_FILE):
                    try: os.remove(LEGACY_SETTINGS_FILE)
                    except OSError: pass
                return d
        except: pass
    return DEFAULT_SETTINGS.copy()

def save_settings(config):
    config["hidden_apps"] = sorted(hidden_apps)          # the "Stop Tracking" list always travels with the settings
    with open(SETTINGS_FILE, "w") as f: json.dump(config, f, indent=4)

system_config = load_settings()
# Apps the user chose to stop tracking. They stay hidden - across restarts and scans - until Restore Hidden Apps is clicked.
hidden_apps = set(system_config.get("hidden_apps", []))
icon_instance, cached_updates, root_window_instance = None, set(), None
notified_updates = set()
_instance_lock_fd = None
_autostart_ui_sync = None      # set by the window so the Preferences switch follows the tray menu
_ui_refresh_hook = None        # set by the window so background scans can redraw its lists
_instance_socket_path = None

def check_app_installed(app_id):
    try:
        res = subprocess.run(host_argv(["flatpak", "info", app_id]), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        return res.returncode == 0
    except: return False

def get_pending_update_ids():
    """Tracked, installed apps that currently have an update waiting - the same
    condition that turns the tray arrow gold."""
    return {aid for aid in list(system_config["apps"].keys()) if aid in cached_updates and aid not in hidden_apps and check_app_installed(aid)}

def play_notification_sound():
    """Plays a short notification sound using whatever the desktop provides:
    libcanberra first, then PulseAudio/PipeWire with the standard freedesktop
    sound theme, then the window-system bell as a last resort. Runs in its own
    thread so it never blocks the UI, and stays silent in the terminal."""
    def _play():
        quiet = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
        if host_which("canberra-gtk-play"):
            try:
                if subprocess.run(host_argv(["canberra-gtk-play", "-i", "message-new-instant"]), timeout=8, **quiet).returncode == 0:
                    return
            except Exception:
                pass
        sound_dirs = ["/usr/share/sounds/freedesktop/stereo", "/usr/share/sounds/ubuntu/stereo", "/usr/share/sounds/gnome/default/alerts"]
        sound_files = ["message-new-instant.oga", "message.oga", "complete.oga", "bell.oga", "dialog-information.oga"]
        sound_path = None if IN_FLATPAK else next((os.path.join(d, f) for d in sound_dirs for f in sound_files if os.path.isfile(os.path.join(d, f))), None)
        if sound_path:
            for player in ("paplay", "pw-play"):
                if shutil.which(player):
                    try:
                        if subprocess.run([player, sound_path], timeout=8, **quiet).returncode == 0:
                            return
                    except Exception:
                        pass
        try:
            if root_window_instance is not None:
                root_window_instance.after(0, root_window_instance.bell)
        except Exception:
            pass
    threading.Thread(target=_play, daemon=True).start()

def detect_flatpak_install_command():
    for binary, cmd in [("apt", "sudo apt install -y flatpak"), ("dnf", "sudo dnf install -y flatpak"), ("pacman", "sudo pacman -S --noconfirm flatpak"), ("zypper", "sudo zypper install -y flatpak")]:
        if shutil.which(binary):
            return cmd
    return None

def _has_flathub_remote():
    try:
        res = subprocess.run(host_argv(["flatpak", "remote-list"]), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        return res.returncode == 0 and "flathub" in res.stdout.lower()
    except Exception:
        return False

def tray_backend_name():
    """Which pystray backend is in use: appindicator, gtk or xorg."""
    try:
        return pystray.Icon.__module__.rsplit("_", 1)[-1]
    except Exception:
        return None

def _gdbus_text(args):
    """Runs a D-Bus call with whichever tool exists; returns its text or None."""
    for tool, cmd in (("gdbus", ["gdbus", "call", "--session"] + args["gdbus"]),
                      ("dbus-send", ["dbus-send", "--session", "--print-reply"] + args["dbus-send"])):
        if shutil.which(tool):
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                if r.returncode == 0:
                    return r.stdout
            except Exception:
                pass
    return None

def _sni_host_registered():
    """True when a status-notifier tray is on screen, False when there is none,
    None when D-Bus can't be queried. A watcher alone isn't enough - the panel
    must have registered as a host, which is exactly what is missing when the
    panel has no system-tray item."""
    watcher = "org.kde.StatusNotifierWatcher"
    names = _gdbus_text({"gdbus": ["--dest", "org.freedesktop.DBus", "--object-path", "/org/freedesktop/DBus", "--method", "org.freedesktop.DBus.ListNames"],
                         "dbus-send": ["--dest=org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus.ListNames"]})
    if names is None:
        try:
            import gi
            gi.require_version("Gio", "2.0")
            from gi.repository import Gio, GLib
            conn = Gio.bus_get_sync(Gio.BusType.SESSION, None)
            res = conn.call_sync("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "ListNames", None, GLib.VariantType("(as)"), Gio.DBusCallFlags.NONE, 3000, None)
            names = " ".join(res.unpack()[0])
        except Exception:
            return None
    if watcher not in names:
        return False
    prop = _gdbus_text({"gdbus": ["--dest", watcher, "--object-path", "/StatusNotifierWatcher", "--method", "org.freedesktop.DBus.Properties.Get", watcher, "IsStatusNotifierHostRegistered"],
                        "dbus-send": ["--dest=" + watcher, "/StatusNotifierWatcher", "org.freedesktop.DBus.Properties.Get", "string:" + watcher, "string:IsStatusNotifierHostRegistered"]})
    if prop is None:
        return True            # a watcher exists but can't be asked more - don't nag
    return "true" in prop.lower()

def _xembed_tray_present():
    """True/False for a classic (XEmbed) system tray; None when it can't be checked.
    Wayland sessions have no classic trays at all."""
    if (os.environ.get("XDG_SESSION_TYPE") or "").lower() == "wayland":
        return False
    try:
        from Xlib import display
        d = display.Display()
        try:
            owner = d.get_selection_owner(d.intern_atom("_NET_SYSTEM_TRAY_S%d" % d.get_default_screen()))
            return getattr(owner, "id", owner) not in (0, None)
        finally:
            d.close()
    except Exception:
        return None

def tray_status():
    """{'present': True/False/None, ...}. Which kinds of tray count depends on the
    backend: appindicator can use either kind, gtk/xorg only draw in a classic tray."""
    sni, xembed, backend = _sni_host_registered(), _xembed_tray_present(), tray_backend_name()
    hosts = [sni, xembed] if backend in (None, "appindicator") else [xembed]
    if any(h is True for h in hosts): present = True
    elif all(h is False for h in hosts): present = False      # every kind checked and none found
    else: present = None                                      # something couldn't be checked: don't guess
    return {"present": present, "sni": sni, "xembed": xembed, "backend": backend}

def tray_setup_instructions():
    desk = ((os.environ.get("XDG_CURRENT_DESKTOP") or "") + ":" + (os.environ.get("DESKTOP_SESSION") or "")).upper()
    if "XFCE" in desk:
        return "Right-click an empty spot on your panel, choose Panel > Panel Preferences > Items, click the + (Add) button and add \"Status Tray Plugin\"."
    if "KDE" in desk or "PLASMA" in desk:
        return "Right-click your panel, choose Add Widgets and add \"System Tray\"."
    if "MATE" in desk:
        return "Right-click your panel, choose Add to Panel and add \"Notification Area\"."
    if "CINNAMON" in desk:
        return "Right-click your panel, choose Applets and turn on \"System Tray\"."
    if "LXQT" in desk:
        return "Right-click your panel, choose Manage Widgets and add the \"Status Notifier Plugin\" (or \"System Tray\")."
    if "LXDE" in desk:
        return "Right-click your panel, choose Add / Remove Panel Items and add \"Notification Area\"."
    if "GNOME" in desk or "UNITY" in desk:
        return "GNOME hides tray icons by default. Install the \"AppIndicator and KStatusNotifierItem Support\" extension (search for it in the Extension Manager app or on extensions.gnome.org)."
    return "Add a \"system tray\", \"notification area\" or \"status notifier\" item to your panel. Right-clicking the panel usually shows how."

def check_flatpak_prerequisites(root):
    if IN_FLATPAK and not host_which("flatpak"):
        messagebox.showerror("Can't reach Flatpak", "Flatpak Manager couldn't run the 'flatpak' command on this computer.\n\nThe sandbox needs permission to talk to the host. Run this once in a terminal, then start the app again:\n\nflatpak override --user --talk-name=org.freedesktop.Flatpak " + FLATPAK_APP_ID)
        return
    if not IN_FLATPAK and not shutil.which("flatpak"):
        install_cmd = detect_flatpak_install_command()
        win = tk.Toplevel(root)
        win.title("Flatpak Not Found")
        win.geometry("460x260")
        win.resizable(False, False)
        win.transient(root)
        win.grab_set()
        ttk.Label(win, text="⚠️ Flatpak Not Installed", font=("Helvetica", 12, "bold")).pack(pady=(15, 5))
        ttk.Label(win, text="Flatpak Manager requires the 'flatpak' command-line tool, which isn't currently installed on this system.\n\nWithout it, scanning, installing, and updating apps won't work.", wraplength=420, justify=tk.LEFT).pack(padx=20, pady=5)
        def do_install():
            if messagebox.askyesno("Confirm Installation", f"This will run the following in a terminal window and ask for your administrator password:\n\n{install_cmd}\n\nContinue?"):
                term_args = get_terminal_command(f'{install_cmd}; read -p "Done. Please restart Flatpak Manager afterward..."')
                if term_args:
                    subprocess.Popen(term_args)
                else:
                    messagebox.showerror("No Terminal Found", f"Couldn't find a terminal emulator to run this command. Please run it manually:\n\n{install_cmd}")
                win.destroy()
        btn_row = ttk.Frame(win); btn_row.pack(pady=15)
        if install_cmd:
            ttk.Button(btn_row, text="Install Flatpak", command=do_install).pack(side=tk.LEFT, padx=5)
        else:
            ttk.Label(win, text="Couldn't automatically detect your package manager. Visit flatpak.org/setup for manual instructions.", wraplength=420, justify=tk.LEFT, foreground="#555555").pack(padx=20, pady=5)
        ttk.Button(btn_row, text="Later", command=win.destroy).pack(side=tk.LEFT, padx=5)
        return
    if not _has_flathub_remote():
        add_cmd = "flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo"
        win = tk.Toplevel(root)
        win.title("Flathub Not Configured")
        win.geometry("460x220")
        win.resizable(False, False)
        win.transient(root)
        win.grab_set()
        ttk.Label(win, text="⚠️ Flathub Not Configured", font=("Helvetica", 12, "bold")).pack(pady=(15, 5))
        ttk.Label(win, text="Flatpak is installed, but the Flathub app store isn't set up yet.\n\nWithout it, searching for and installing new apps won't work.", wraplength=420, justify=tk.LEFT).pack(padx=20, pady=5)
        def do_add():
            if messagebox.askyesno("Confirm", f"This will run the following in a terminal window:\n\n{add_cmd}\n\nContinue?"):
                term_args = get_terminal_command(f'{add_cmd}; read -p "Done..."')
                if term_args:
                    subprocess.Popen(term_args)
                else:
                    messagebox.showerror("No Terminal Found", f"Couldn't find a terminal emulator to run this command. Please run it manually:\n\n{add_cmd}")
                win.destroy()
        btn_row = ttk.Frame(win); btn_row.pack(pady=15)
        ttk.Button(btn_row, text="Add Flathub", command=do_add).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_row, text="Later", command=win.destroy).pack(side=tk.LEFT, padx=5)

def get_terminal_command(shell_cmd):
    """Builds a Popen argument list that opens a visible terminal running
    shell_cmd, trying common terminal emulators across desktop environments
    so the app isn't limited to Debian/Ubuntu's x-terminal-emulator alias.
    Returns None if no known terminal emulator is found on this system."""
    wrapped = "/bin/bash -c " + shlex.quote(shell_cmd)
    candidates = [
        ("x-terminal-emulator", ["-e", wrapped]),
        ("gnome-terminal", ["--", "/bin/bash", "-c", shell_cmd]),
        ("konsole", ["-e", "/bin/bash", "-c", shell_cmd]),
        ("xfce4-terminal", ["-e", wrapped]),
        ("mate-terminal", ["-e", wrapped]),
        ("lxterminal", ["-e", wrapped]),
        ("tilix", ["-e", "/bin/bash", "-c", shell_cmd]),
        ("xterm", ["-e", "/bin/bash", "-c", shell_cmd]),
    ]
    for binary, args in candidates:
        if host_which(binary):
            return host_argv([binary] + args, gui=True)
    return None

def _pid_alive(pid):
    if IN_FLATPAK:                          # the pid belongs to the host, which this sandbox can't see - ask the host
        try:
            r = subprocess.run(host_argv(["sh", "-c", '[ -r /proc/%d/stat ] && ! grep -q "^State:[[:space:]]*Z" /proc/%d/status' % (pid, pid)]), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
            return r.returncode == 0
        except (OSError, subprocess.SubprocessError):
            return True                     # can't tell - assume it is still running rather than report a false "interrupted"
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    try:                                   # a process that has exited but not yet been reaped counts as gone
        with open("/proc/%d/stat" % pid) as f:
            return f.read().rsplit(")", 1)[-1].split()[0] != "Z"
    except (OSError, IndexError):
        return True

def launch_tracked_command(cmd):
    """Runs `cmd` in a visible terminal window and returns a handle for wait_for_command(),
    or None when no terminal emulator is available.
    The command itself records when it starts and when it ends, so completion is detected
    the same way on every terminal - including ones that hand off and return immediately,
    and ones that stay open until you press Enter."""
    state = tempfile.mkdtemp(prefix="flatpak_manager_op_")
    pid_file, done_file = os.path.join(state, "pid"), os.path.join(state, "done")
    shell_cmd = "echo $$ > %s; %s; echo $? > %s; read -p \"Done...\"" % (shlex.quote(pid_file), cmd, shlex.quote(done_file))
    term_args = get_terminal_command(shell_cmd)
    if not term_args:
        shutil.rmtree(state, ignore_errors=True)
        return None
    return {"state": state, "pid_file": pid_file, "done_file": done_file, "proc": subprocess.Popen(term_args)}

def wait_for_command(handle, start_grace=90):
    """Blocks (call it from a worker thread) until the command from launch_tracked_command() ends.
    Returns ("finished", exit_status), ("interrupted", None) when the window was closed or the
    command killed before it finished, or ("never_started", None) when the terminal never ran it."""
    started, pid, tick = time.time(), None, 0
    try:
        while True:
            tick += 1
            if os.path.exists(handle["done_file"]):
                try:
                    with open(handle["done_file"]) as f: status = int(f.read().strip() or "-1")
                except (OSError, ValueError):
                    status = -1
                return "finished", status
            if pid is None and os.path.exists(handle["pid_file"]):
                try:
                    with open(handle["pid_file"]) as f: pid = int(f.read().strip())
                except (OSError, ValueError):
                    pid = None                              # still being written - look again next time round
            if pid is not None and (not IN_FLATPAK or tick % 4 == 0) and not _pid_alive(pid):   # inside a sandbox each check costs a host process, so look every 2s
                time.sleep(0.2)
                if os.path.exists(handle["done_file"]):
                    continue                                # it finished just as we looked
                return "interrupted", None
            if pid is None:
                rc = handle["proc"].poll()
                if (rc not in (None, 0)) or time.time() - started > start_grace:
                    return "never_started", None
            time.sleep(0.5)
    finally:
        shutil.rmtree(handle["state"], ignore_errors=True)

def _open_link_quietly(url):
    """Opens a URL in the default browser while suppressing the noisy
    sandbox/GTK-module warnings Flatpak-packaged browsers print to stderr.
    Since the browser launches as a separate process, redirecting our own
    stderr just for the launch call is enough to keep it quiet permanently."""
    try:
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        saved_fd = os.dup(2)
        os.dup2(devnull_fd, 2)
    except OSError:
        webbrowser.open(url)
        return
    try:
        webbrowser.open(url)
    finally:
        try:
            os.dup2(saved_fd, 2)
            os.close(saved_fd)
            os.close(devnull_fd)
        except OSError:
            pass

def get_apps_with_updates():
    upgradable_ids = set()
    try:
        res = subprocess.run(host_argv(["flatpak", "remote-ls", "--updates", "--app", "--columns=application"]), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20)
        if res.returncode == 0:
            for line in res.stdout.strip().split('\n'):
                aid = line.strip()
                if aid and aid.lower() != "application":
                    upgradable_ids.add(aid)
    except: pass
    return upgradable_ids

def run_silent_flatpak_scan():
    global system_config
    try:
        res = subprocess.run(host_argv(["flatpak", "list", "--app", "--columns=name,application"]), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if res.returncode == 0:
            changes = False
            found_ids = set()
            for line in res.stdout.strip().split('\n'):
                if not line or line.startswith("Name") or "application id" in line.lower(): continue
                parts = [p.strip() for p in re.split(r'\t|\s{2,}', line) if p.strip()]
                if len(parts) >= 2:
                    name, aid = parts[0], parts[1]
                    found_ids.add(aid)
                    if aid not in system_config["apps"]:
                        system_config["apps"][aid] = name
                        changes = True
            stale_ids = [aid for aid in system_config["apps"] if aid not in found_ids]
            for aid in stale_ids:
                del system_config["apps"][aid]
                hidden_apps.discard(aid)          # if it is ever reinstalled it starts fresh, not hidden
                changes = True
            if changes: save_settings(system_config)
    except: pass
class ModernToggleSwitch(tk.Canvas):
    def __init__(self, parent, command=None, initial_state=False, enabled=True, **kwargs):
        bg_color = ttk.Style().lookup("TFrame", "background") or "#f0f0f0"
        super().__init__(parent, width=54, height=26, bg=bg_color, bd=0, highlightthickness=0, cursor="hand2", **kwargs)
        self.command, self.state, self.enabled = command, initial_state, enabled
        self.bind("<Button-1>", self.toggle_state_event)
        self.bind("<Return>", lambda e: self.toggle_state_event(None))
        self.draw_toggle_element()

    def draw_toggle_element(self):
        self.delete("all")
        self.configure(cursor="hand2" if self.enabled else "arrow")
        if self.state:
            on_color = "#4cd964" if self.enabled else "#c7c7cc"
            self.create_rounded_rect(2, 2, 52, 24, radius=11, fill=on_color)
            self.create_oval(30, 4, 50, 24, fill="#ffffff", outline="")
        else:
            self.create_rounded_rect(2, 2, 52, 24, radius=11, fill="#e5e5ea")
            self.create_oval(4, 4, 24, 24, fill="#ffffff", outline="")

    def set_enabled(self, enabled):
        self.enabled = enabled
        self.draw_toggle_element()

    def create_rounded_rect(self, x1, y1, x2, y2, radius=5, **kwargs):
        pts = [x1+radius, y1, x2-radius, y1, x2, y1, x2, y1+radius, x2, y2-radius, x2, y2, x2-radius, y2, x1+radius, y2, x1, y2, x1, y2-radius, x1, y1+radius, x1, y1]
        return self.create_polygon(pts, **kwargs, smooth=True)

    def toggle_state_event(self, event):
        if not self.enabled: return
        self.state = not self.state
        self.draw_toggle_element()
        if self.command: self.command(self.state)

def create_arrow_icon(color_mode):
    image = Image.new('RGBA', (64, 64), color=(0, 0, 0, 0))
    dc = ImageDraw.Draw(image)
    fill_color = (46, 204, 113, 255) if color_mode == "green" else (255, 224, 130, 255)
    dc.polygon([(24, 8), (40, 8), (40, 36), (54, 36), (32, 58), (10, 36), (24, 36)], fill=fill_color)
    return image

def toggle_window_visibility():
    global root_window_instance
    if root_window_instance:
        root_window_instance.after(0, lambda: [root_window_instance.deiconify(), root_window_instance.lift()])

def _autostart_file():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, "autostart", "flatpak-manager.desktop")

def _desktop_exec_quote(arg):
    """Quote one argument for the Exec= line of a .desktop file (freedesktop spec)."""
    if re.fullmatch(r"[A-Za-z0-9_./+:@%-]+", arg):
        return arg
    arg = arg.replace("\\", "\\\\\\\\").replace('"', '\\\\"').replace("`", "\\\\`").replace("$", "\\\\$")
    return '"' + arg + '"'

_HOST_AUTOSTART_DIR = '"${XDG_CONFIG_HOME:-$HOME/.config}/autostart"'
_autostart_cache = {"t": 0.0, "v": False}

def _host_sh(script, text=None):
    try:
        return subprocess.run(host_argv(["sh", "-c", script]), input=text, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError):
        return None

def autostart_enabled():
    """True when a login-startup entry for Flatpak Manager exists and is switched on."""
    if IN_FLATPAK:
        if time.time() - _autostart_cache["t"] < 10:        # the tray menu asks every few seconds; don't spawn a host process each time
            return _autostart_cache["v"]
        r = _host_sh("cat %s/%s.desktop" % (_HOST_AUTOSTART_DIR, FLATPAK_APP_ID))
        value = False
        if r is not None and r.returncode == 0:
            lines = [ln.strip().replace(" ", "").lower() for ln in r.stdout.splitlines()]
            value = "hidden=true" not in lines and "x-gnome-autostart-enabled=false" not in lines
        _autostart_cache.update(t=time.time(), v=value)
        return value
    try:
        with open(_autostart_file(), encoding="utf-8") as f:
            lines = [ln.strip().replace(" ", "").lower() for ln in f]
    except OSError:
        return False
    return "hidden=true" not in lines and "x-gnome-autostart-enabled=false" not in lines

def set_autostart(enabled):
    """Turns start-at-login on or off. Returns False if the file couldn't be written."""
    if IN_FLATPAK:
        if enabled:
            text = ("[Desktop Entry]\nType=Application\nName=Flatpak Manager\n"
                    "Comment=Keeps your Flatpak apps updated (starts quietly in the system tray)\n"
                    "Exec=flatpak run " + FLATPAK_APP_ID + " --background\nIcon=" + FLATPAK_APP_ID + "\nTerminal=false\nStartupNotify=false\n"
                    "X-Flatpak=" + FLATPAK_APP_ID + "\nX-GNOME-Autostart-enabled=true\nX-GNOME-Autostart-Delay=3\n")
            r = _host_sh('d=%s; mkdir -p "$d" && cat > "$d/%s.desktop"' % (_HOST_AUTOSTART_DIR, FLATPAK_APP_ID), text)
        else:
            r = _host_sh("rm -f %s/%s.desktop" % (_HOST_AUTOSTART_DIR, FLATPAK_APP_ID))
        ok = r is not None and r.returncode == 0
        if ok:
            _autostart_cache.update(t=time.time(), v=bool(enabled))
        return ok
    path = _autostart_file()
    try:
        if enabled:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            exec_line = " ".join(_desktop_exec_quote(a) for a in (sys.executable, os.path.abspath(__file__), "--background"))
            text = ("[Desktop Entry]\nType=Application\nName=Flatpak Manager\n"
                    "Comment=Keeps your Flatpak apps updated (starts quietly in the system tray)\n"
                    "Exec=" + exec_line + "\nIcon=system-software-install\nTerminal=false\nStartupNotify=false\n"
                    "X-GNOME-Autostart-enabled=true\nX-GNOME-Autostart-Delay=3\n")
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(text)
            os.replace(tmp, path)
        else:
            try:
                os.remove(path)
            except FileNotFoundError:
                pass
        return True
    except OSError:
        return False

def _toggle_autostart_from_tray():
    set_autostart(not autostart_enabled())
    try:
        if icon_instance: icon_instance.update_menu()
    except Exception:
        pass
    cb = _autostart_ui_sync
    if cb:
        try: cb()
        except Exception: pass

def create_menu_items(pending_ids=None):
    menu_items = []
    global system_config, icon_instance, cached_updates
    if pending_ids is None:
        pending_ids = get_pending_update_ids()
    action_count = len(pending_ids)
    if icon_instance:
        if action_count == 0:
            icon_instance.icon = create_arrow_icon("green")
            menu_items.append(pystray.MenuItem("✨ All Flatpaks up-to-date", lambda x: None, enabled=False))
        else:
            icon_instance.icon = create_arrow_icon("yellow")
            menu_items.append(pystray.MenuItem(f"⚠️ View updates ({action_count} pending)", lambda icon, item: toggle_window_visibility()))
    menu_items.extend([pystray.Menu.SEPARATOR, pystray.MenuItem("⚙️ Settings Manager", lambda icon, item: toggle_window_visibility()), pystray.MenuItem("🚀 Start at login", lambda icon, item: _toggle_autostart_from_tray(), checked=lambda item: autostart_enabled()), pystray.MenuItem("Quit", lambda icon, item: clean_shutdown_routine())])
    return pystray.Menu(*menu_items)

def _suppress_startup_stderr_noise(duration=2.0):
    """Temporarily redirects OS-level stderr to devnull to hide the harmless
    'libayatana-appindicator is deprecated' notice the OS library prints when
    the tray icon initializes, then restores it automatically."""
    try:
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        saved_fd = os.dup(2)
        os.dup2(devnull_fd, 2)
    except OSError:
        return
    def restore():
        time.sleep(duration)
        try:
            os.dup2(saved_fd, 2)
            os.close(saved_fd)
            os.close(devnull_fd)
        except OSError:
            pass
    threading.Thread(target=restore, daemon=True).start()

def _notify_ui_refresh():
    """Asks the window (if there is one) to redraw its lists, e.g. after a background scan."""
    hook = _ui_refresh_hook
    if hook:
        try: hook()
        except Exception: pass

def background_orchestrator(initial_delay=0):
    global system_config, cached_updates, icon_instance, notified_updates
    if initial_delay:
        time.sleep(initial_delay)       # started at login: give the panel a moment to load its tray
    if system_config.get("auto_scan_enabled", False) and "On boot" in system_config.get("scan_intervals", []):
        run_silent_flatpak_scan()
        cached_updates = get_apps_with_updates()
        system_config["last_scan_time"] = time.time()
        save_settings(system_config)
        _notify_ui_refresh()
    try:
        _suppress_startup_stderr_noise()
        icon_instance = pystray.Icon("Flatpak Manager", create_arrow_icon("yellow"), "Flatpak Manager", create_menu_items())
        threading.Thread(target=icon_instance.run, daemon=True).start()
    except Exception as e:
        icon_instance = None
        print(f"[Flatpak Manager] Tray icon unavailable on this desktop: {e}")
        print("[Flatpak Manager] Ensure a system tray / indicator applet is enabled in your desktop panel.")
    while True:
        time.sleep(15)
        try:
            pending = get_pending_update_ids()
        except Exception:
            pending = None
        if icon_instance:
            icon_instance.menu = create_menu_items(pending)
            icon_instance.update_menu()
        if pending is not None:
            new_updates = pending - notified_updates
            notified_updates = set(pending)
            if new_updates and system_config.get("sounds_enabled", False):
                play_notification_sound()
        if system_config.get("auto_scan_enabled", False):
            elapsed = time.time() - system_config.get("last_scan_time", 0.0)
            sec = None
            arr = system_config.get("scan_intervals", [])
            if "Every 1 hour" in arr: sec = 3600
            elif "Every 3 hours" in arr: sec = 10800
            elif "Once per day" in arr: sec = 86400
            elif "Once per week" in arr: sec = 604800
            if sec and elapsed >= sec:
                run_silent_flatpak_scan()
                cached_updates = get_apps_with_updates()
                system_config["last_scan_time"] = time.time()
                save_settings(system_config)
                _notify_ui_refresh()

def clean_shutdown_routine():
    global icon_instance, root_window_instance
    try:
        if icon_instance: icon_instance.stop()
    except: pass
    try:
        if root_window_instance: root_window_instance.quit()
    except: pass
    try:
        if _instance_socket_path: os.unlink(_instance_socket_path)
    except OSError: pass
    os._exit(0)
def show_settings_window(pending_file=None, ipc_server=None, start_hidden=False, startup_notice=None):
    global system_config, cached_updates, root_window_instance, _autostart_ui_sync, _ui_refresh_hook
    if root_window_instance is not None:
        try: root_window_instance.deiconify(); root_window_instance.lift(); return
        except: root_window_instance = None

    root = tk.Tk()
    root_window_instance = root
    root.title("Flatpak Manager")
    root.resizable(False, False)
    root.geometry(f"660x680+{root.winfo_screenwidth()-680}+{root.winfo_screenheight()-740}")
    root.protocol("WM_DELETE_WINDOW", lambda: root.withdraw())
    if start_hidden:
        root.withdraw()                 # started at login: live quietly in the tray
        _first_map = {}
        def _on_first_show(event):
            if event.widget is root:
                root.unbind("<Map>", _first_map["id"])
                check_flatpak_prerequisites(root)       # the "Flatpak/Flathub missing" prompts, now that someone is looking
        _first_map["id"] = root.bind("<Map>", _on_first_show, add="+")
    else:
        check_flatpak_prerequisites(root)
    secondary_labels = []
    app_fonts = {role: tkfont.Font(**spec) for role, spec in FONT_ROLE_SPECS.items()}
    base_tk_font_sizes = {}
    for fname in TK_NAMED_FONTS:
        try: base_tk_font_sizes[fname] = tkfont.nametofont(fname).actual("size")
        except tk.TclError: pass

    banner_frame = tk.Frame(root, bg="#ffe082")
    banner_label = tk.Label(banner_frame, text="", bg="#ffe082", fg="#1c1c1e", font=app_fonts["bold10"])
    banner_label.pack(side="left", padx=15, pady=8, expand=True)
    banner_timer = None

    def trigger_banner_popup(msg):
        nonlocal banner_timer
        banner_label.configure(text=msg)
        if not banner_frame.winfo_ismapped():
            banner_frame.pack(fill="x", side="top", before=notebook)
        if banner_timer: root.after_cancel(banner_timer)
        banner_timer = root.after(5000, lambda: [banner_frame.pack_forget(), banner_label.configure(text="")])

    footer_frame = ttk.Frame(root)
    footer_frame.pack(side=tk.BOTTOM, fill=tk.X)
    notebook = ttk.Notebook(root)
    notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    tab_apps, tab_manage = ttk.Frame(notebook, padding="12"), ttk.Frame(notebook, padding="12")
    tab_prefs_outer = ttk.Frame(notebook)
    prefs_canvas = tk.Canvas(tab_prefs_outer, highlightthickness=0, bd=0, yscrollincrement=20)
    prefs_scroll = ttk.Scrollbar(tab_prefs_outer, orient=tk.VERTICAL, command=prefs_canvas.yview)
    prefs_canvas.configure(yscrollcommand=prefs_scroll.set)
    prefs_scroll.pack(side=tk.RIGHT, fill=tk.Y)
    prefs_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    tab_prefs = ttk.Frame(prefs_canvas, padding="12")
    prefs_window = prefs_canvas.create_window((0, 0), window=tab_prefs, anchor="nw")
    tab_prefs.bind("<Configure>", lambda e: prefs_canvas.configure(scrollregion=prefs_canvas.bbox("all")))
    prefs_canvas.bind("<Configure>", lambda e: prefs_canvas.itemconfigure(prefs_window, width=e.width))

    def _prefs_mousewheel(event):
        try:
            w = root.winfo_containing(event.x_root, event.y_root)
        except (KeyError, tk.TclError):
            return
        while w is not None and w is not tab_prefs_outer:
            w = w.master
        if w is None:
            return
        lo, hi = prefs_canvas.yview()
        if lo <= 0.0 and hi >= 1.0:
            return
        if event.num == 4: step = -1
        elif event.num == 5: step = 1
        else: step = -1 if event.delta > 0 else 1
        prefs_canvas.yview_scroll(step * 3, "units")
    for _seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
        root.bind_all(_seq, _prefs_mousewheel, add="+")

    tab_tools = ttk.Frame(notebook, padding="12")
    tab_info = ttk.Frame(notebook, padding="16")
    
    notebook.add(tab_apps, text=" 📋 Monitor ")
    notebook.add(tab_manage, text=" 📦 Manage Apps ")
    notebook.add(tab_prefs_outer, text=" ⚙️ Preferences ")
    notebook.add(tab_tools, text=" 🛠️ Tools ")
    notebook.add(tab_info, text=" Help & Info ")

    global app_keys, system_flatpaks
    app_keys, system_flatpaks = [], []

    refresh_generation = [0]
    def refresh_list():
        """Redraws the Monitor list. The per-app 'is it installed?' checks (one flatpak call each) run
        in the background, several at a time, so the window never freezes - even with dozens of apps."""
        refresh_generation[0] += 1
        generation = refresh_generation[0]
        rows = [(aid, system_config["apps"][aid]) for aid in list(system_config["apps"].keys()) if aid not in hidden_apps]
        def compute():
            try:
                with ThreadPoolExecutor(max_workers=8) as pool:
                    installed = list(pool.map(check_app_installed, [aid for aid, _ in rows]))
            except Exception:
                installed = [check_app_installed(aid) for aid, _ in rows]
            try: root.after(0, lambda: apply_rows(generation, rows, installed))
            except (RuntimeError, tk.TclError): pass
        threading.Thread(target=compute, daemon=True).start()

    def apply_rows(generation, rows, installed):
        global app_keys
        if generation != refresh_generation[0]:
            return                                   # a newer redraw is already on its way
        keep = set()                                 # every selected app, so a redraw never changes what is selected
        first_aid, top = None, 0.0
        try:
            for i in listbox.curselection():
                text = listbox.get(i)
                if "(" in text: keep.add(text.rsplit("(", 1)[-1].rstrip(")"))
            top = listbox.yview()[0]
            if listbox.size() and top > 0.0:         # remember which app was at the top of the view
                text = listbox.get(listbox.nearest(0))
                if "(" in text: first_aid = text.rsplit("(", 1)[-1].rstrip(")")
        except tk.TclError:
            pass
        # Order: apps with an update first, then everything else A-Z (each group A-Z, ignoring case).
        entries = [(aid, name, bool(is_installed), bool(is_installed and aid in cached_updates)) for (aid, name), is_installed in zip(rows, installed)]
        entries.sort(key=lambda e: (not e[3], e[1].casefold(), e[0]))
        listbox.delete(0, tk.END)
        app_keys = []
        updates_waiting = 0
        for aid, name, is_installed, has_update in entries:
            status = "✨ [UPDATE] " if has_update else ("✅ " if is_installed else "📥 ")
            listbox.insert(tk.END, f"{status} {name} ({aid})")
            app_keys.append(aid)
            if has_update:
                updates_waiting += 1
                listbox.itemconfig(tk.END, background=UPDATE_GOLD, foreground=UPDATE_GOLD_TEXT, selectbackground=UPDATE_GOLD_SELECTED, selectforeground=UPDATE_GOLD_TEXT)
            if aid in keep: listbox.selection_set(tk.END)
        if first_aid in app_keys:
            listbox.yview(app_keys.index(first_aid))  # scrolled down: stay on the same app. At the very top: stay at the top so new updates show.
        else:
            listbox.yview_moveto(0.0 if top <= 0.0 else top)
        update_action_button_state()
        lbl_tracked_count.config(text=f"Tracked Applications: {len(app_keys)}")
        set_updates_strip(updates_waiting)
        try: update_hidden_note()
        except (tk.TclError, NameError): pass

    def selected_update_aids():
        """IDs of the selected rows that have an update waiting (the gold ones)."""
        aids = []
        try:
            for idx in listbox.curselection():
                text = listbox.get(idx)
                if "(" in text and text.lstrip().startswith("✨ [UPDATE]"):
                    aids.append(text.rsplit("(", 1)[-1].rstrip(")"))
        except tk.TclError:
            pass
        return aids

    def update_action_button_state(*args):
        n = len(selected_update_aids())
        try:
            btn_update_app.config(text="🆙 Update Selected App" if n <= 1 else "🆙 Update %d Selected Apps" % n, state="normal" if n else "disabled")
        except (tk.TclError, NameError):
            pass

    def run_direct_inapp_update():
        aids = selected_update_aids()
        if not aids:
            return
        names = [system_config["apps"].get(a, a) for a in aids]
        # One terminal, one flatpak command for everything selected.
        cmd = "flatpak update -y " + " ".join(shlex.quote(a) for a in aids) + " && flatpak uninstall --unused -y"
        handle = launch_tracked_command(cmd)
        if not handle:
            messagebox.showerror("No Terminal Found", "Couldn't find a terminal emulator on this system to run the update.")
            return
        what = names[0] if len(aids) == 1 else "%d apps" % len(aids)
        trigger_banner_popup(f"Event: Updating {what}...")
        def finish():
            outcome, status = wait_for_command(handle)
            if outcome == "never_started":
                root.after(0, lambda: messagebox.showerror("Flatpak Manager", "The terminal window for the update didn't start, so nothing was changed."))
                return
            if outcome == "finished" and status == 0:
                for a in aids: cached_updates.discard(a)
                root.after(0, refresh_list)                                  # clear the gold straight away...
                still = set(get_apps_with_updates()) & set(aids)             # ...then check whether anything didn't finish
                if still:
                    cached_updates.update(still)
                    left = ", ".join(system_config["apps"].get(a, a) for a in sorted(still))
                    root.after(0, lambda: [refresh_list(), trigger_banner_popup(f"Event: Not finished, still listed: {left}")])
                else:
                    root.after(0, lambda: trigger_banner_popup(f"Event: Update finished for {what}."))
            else:
                why = f"didn't complete (exit code {status})" if outcome == "finished" else "was interrupted - the terminal window was closed early"
                root.after(0, lambda: trigger_banner_popup(f"Event: The update {why}."))
                scan_everything()                                            # re-check what is really still waiting
        threading.Thread(target=finish, daemon=True).start()

    def refresh_system_installed_list():
        def load_installed_worker():
            local_flatpaks = []
            try:
                res = subprocess.run(host_argv(["flatpak", "list", "--app", "--columns=name,application"]), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if res.returncode == 0:
                    for line in res.stdout.strip().split('\n'):
                        if not line or line.startswith("Name") or "application id" in line.lower(): continue
                        parts = [p.strip() for p in re.split(r'\t|\s{2,}', line) if p.strip()]
                        if len(parts) >= 2:
                            name, fid = parts[0], parts[1]
                            local_flatpaks.append((name, fid))
                root.after(0, lambda: update_installed_ui_element(local_flatpaks))
            except: pass

        def update_installed_ui_element(data_list):
            global system_flatpaks
            keep_fid = None
            try:
                sel = manage_listbox.curselection()
                if sel:
                    text = manage_listbox.get(sel[0])
                    if "(" in text: keep_fid = text.rsplit("(", 1)[-1].rstrip(")")
                top = manage_listbox.yview()[0]
            except tk.TclError:
                top = 0.0
            manage_listbox.delete(0, tk.END)
            system_flatpaks = sorted(data_list, key=lambda t: (t[0].casefold(), t[1]))
            for name, fid in system_flatpaks:
                manage_listbox.insert(tk.END, f"🖥️  {name} ({fid})")
                if fid == keep_fid: manage_listbox.selection_set(tk.END)
            manage_listbox.yview_moveto(top)
            uns.configure(text=f" 🔥 Installed Applications & Purge Hub ({len(system_flatpaks)}) ")

        threading.Thread(target=load_installed_worker, daemon=True).start()

    def scan_everything():
        """The same sweep Manual Scan Now does (new apps + waiting updates), run quietly in the background."""
        def worker():
            global cached_updates
            run_silent_flatpak_scan()
            cached_updates = get_apps_with_updates()
            try: save_settings(system_config)
            except OSError: pass
            root.after(0, lambda: [refresh_list(), refresh_system_installed_list()])
        threading.Thread(target=worker, daemon=True).start()

    active_setups = [0]
    def track_operation(handle, label, show_spinner=False, on_success=None, success_text=None):
        """Watches a terminal job in the background. When it ends: say how it went, then run ONE full scan."""
        if show_spinner:
            active_setups[0] += 1
            search_spinner_label.config(text="⏳ Setup active...")
        def worker():
            outcome, status = wait_for_command(handle)
            def ui():
                if show_spinner:
                    active_setups[0] = max(0, active_setups[0] - 1)
                    if not active_setups[0]: search_spinner_label.config(text="")
                if outcome == "never_started":
                    messagebox.showerror("Flatpak Manager", f"The terminal window for '{label}' didn't start, so nothing was changed.")
                    return
                if outcome == "finished" and status == 0:
                    if on_success: on_success()
                    trigger_banner_popup(success_text or f"Event: {label} finished.")
                elif outcome == "finished":
                    trigger_banner_popup(f"Event: {label} didn't complete (exit code {status}) - see the terminal window.")
                else:
                    trigger_banner_popup(f"Event: {label} was interrupted - the terminal window was closed early.")
                scan_everything()
            root.after(0, ui)
        threading.Thread(target=worker, daemon=True).start()

    def trigger_manual_scan():
        trigger_banner_popup("Event: Running online updates sweep...")
        def manual_scan_worker():
            run_silent_flatpak_scan()
            global cached_updates
            cached_updates = get_apps_with_updates()
            save_settings(system_config)
            root.after(0, lambda: [refresh_list(), refresh_system_installed_list(), messagebox.showinfo("Scan Complete", "Updates sweep finished successfully!")])
        threading.Thread(target=manual_scan_worker, daemon=True).start()
    def direct_system_install():
        raw_query = direct_install_entry.get().strip()
        if not raw_query: return
        search_spinner_label.config(text="⏳ Querying Flathub...")
        root.update_idletasks()
        def run_async_lookup():
            try:
                res = subprocess.run(host_argv(["flatpak", "search", "--columns=application,name", raw_query]), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=12)
                lines = res.stdout.strip().split('\n') if res.returncode == 0 else []
                valid_matches = []
                for line in lines:
                    if not line or "application id" in line.lower() or "description" in line.lower() or line.startswith("Name"): continue
                    parts = [p.strip() for p in re.split(r'\t|\s{2,}', line) if p.strip()]
                    if len(parts) >= 2:
                        cur_id, cur_name = parts[0], parts[1]
                        if cur_id.count('.') >= 2: valid_matches.append((str(cur_id), str(cur_name)))
            except: valid_matches = []
            def render_selection_interface():
                search_spinner_label.config(text="")
                if not valid_matches:
                    messagebox.showinfo("No Results", f"No applications found on Flathub matching '{raw_query}'.")
                    return
                sel_win = tk.Toplevel(root)
                sel_win.title(f"Search Results for '{raw_query}'")
                sel_win.geometry("580x340")
                sel_win.resizable(False, False)
                sel_win.transient(root)
                sel_win.grab_set()
                _c = THEME_COLORS["dark"] if system_config.get("dark_mode", False) else THEME_COLORS["light"]
                sel_win.configure(bg=_c["bg"])
                lbl_guidance = ttk.Label(sel_win, text="Multiple matches found on Flathub. Select the application you wish to install:", font=app_fonts["bold9"])
                lbl_guidance.pack(anchor=tk.W, padx=15, pady=(12, 5))
                tree_frame = ttk.Frame(sel_win)
                tree_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=5)
                results_listbox = tk.Listbox(tree_frame, height=10, font=app_fonts["body10"], bg=_c["widget_bg"], fg=_c["fg"], selectbackground=_c["select_bg"])
                scroll_bar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=results_listbox.yview)
                results_listbox.configure(yscrollcommand=scroll_bar.set)
                scroll_bar.pack(side=tk.RIGHT, fill=tk.Y)
                results_listbox.pack(fill=tk.BOTH, expand=True)
                for idx, (app_id, app_name) in enumerate(valid_matches):
                    results_listbox.insert(tk.END, f"📦 {app_name} — ({app_id})")
                btn_container = ttk.Frame(sel_win, padding="10")
                btn_container.pack(fill=tk.X, side=tk.BOTTOM)
                def proceed_with_selected_target():
                    selection = results_listbox.curselection()
                    if not selection: return
                    target_id, target_name = valid_matches[selection[0]]
                    sel_win.destroy()
                    handle = launch_tracked_command(f'flatpak install flathub -y {shlex.quote(target_id)}')
                    if not handle:
                        messagebox.showerror("No Terminal Found", "Couldn't find a terminal emulator on this system to run the install.")
                        search_spinner_label.config(text="")
                        return
                    track_operation(handle, f"Install of {target_id}", show_spinner=True, on_success=lambda: direct_install_entry.delete(0, tk.END), success_text="Event: Install finished - scanning for the new app...")
                ttk.Button(btn_container, text="Install Selected App", command=proceed_with_selected_target).pack(side=tk.RIGHT, padx=5)
                ttk.Button(btn_container, text="Cancel", command=sel_win.destroy).pack(side=tk.RIGHT, padx=5)
            root.after(0, render_selection_interface)
        threading.Thread(target=run_async_lookup, daemon=True).start()

    def direct_system_uninstall():
        try:
            sel = manage_listbox.curselection()
            if not sel: return
            idx = sel[0]
            raw_text = manage_listbox.get(idx)
            fid = ""
            if '(' in raw_text: fid = raw_text.rsplit('(', 1)[-1].rstrip(')')
            if not fid: return
            if messagebox.askyesno("Confirm PURGE", f"Completely uninstall application '{fid}' from your system?"):
                handle = launch_tracked_command(f'flatpak uninstall -y {shlex.quote(fid)}')
                if not handle:
                    messagebox.showerror("No Terminal Found", "Couldn't find a terminal emulator on this system to run the uninstall.")
                    return
                def forget_app():
                    system_config["apps"].pop(fid, None)
                    hidden_apps.discard(fid)
                    try: save_settings(system_config)
                    except OSError: pass
                track_operation(handle, f"Uninstall of {fid}", on_success=forget_app, success_text=f"Event: {fid} was uninstalled.")
        except: pass

    def install_from_file(filepath):
        if not filepath or not os.path.isfile(filepath):
            return
        if messagebox.askyesno("Confirm Installation", describe_install_file(filepath)):
            handle = launch_tracked_command(f'flatpak install -y {shlex.quote(filepath)}')
            if not handle:
                messagebox.showerror("No Terminal Found", "Couldn't find a terminal emulator on this system to run the install.")
                return
            track_operation(handle, "Install from file", show_spinner=True, success_text="Event: Install finished - scanning for the new app...")

    def browse_and_install_file():
        filepath = filedialog.askopenfilename(title="Select a Flatpak file", filetypes=[("Flatpak Files", "*.flatpakref *.flatpak"), ("All Files", "*.*")])
        install_from_file(filepath)

    def run_tracking_removal():
        try:
            aids = []
            for idx in listbox.curselection():
                text = listbox.get(idx)
                if "(" in text: aids.append(text.rsplit("(", 1)[-1].rstrip(")"))
            if not aids: return
            if len(aids) == 1:
                prompt = f"Stop tracking '{aids[0]}'?\n\nIt will be hidden here and won't trigger update alerts until you click Restore Hidden Apps."
                note = f"Event: Stopped tracking '{aids[0]}' - Restore Hidden Apps brings it back"
            else:
                prompt = f"Stop tracking these {len(aids)} applications?\n\nThey will be hidden here and won't trigger update alerts until you click Restore Hidden Apps."
                note = f"Event: Stopped tracking {len(aids)} apps - Restore Hidden Apps brings them back"
            if messagebox.askyesno("Confirm Removal", prompt):
                hidden_apps.update(aids)
                try: save_settings(system_config)
                except OSError: pass
                refresh_list()
                if icon_instance:
                    icon_instance.menu = create_menu_items()
                    icon_instance.update_menu()
                root.after(0, lambda: trigger_banner_popup(note))
        except Exception:
            pass
    def restore_hidden_apps():
        """Lists every app hidden with 'Stop Tracking Target' again (and lets their update alerts work again)."""
        if not hidden_apps:
            return
        n = len([a for a in system_config["apps"] if a in hidden_apps])
        hidden_apps.clear()
        try: save_settings(system_config)
        except OSError: pass
        refresh_list()
        if icon_instance:
            icon_instance.menu = create_menu_items()
            icon_instance.update_menu()
        if n:
            trigger_banner_popup("Event: Restored %d hidden app%s to the list" % (n, "" if n == 1 else "s"))

    fh = ttk.Frame(tab_apps); fh.pack(fill=tk.X, pady=5)
    lbl_tracked_count = ttk.Label(fh, text="Tracked Applications:", font=app_fonts["bold10"]); lbl_tracked_count.pack(side=tk.LEFT)
    ttk.Button(fh, text="🔄 Manual Scan Now", command=trigger_manual_scan).pack(side=tk.RIGHT)
    lbl_updates_strip = tk.Label(tab_apps, text="", bg=UPDATE_GOLD, fg=UPDATE_GOLD_TEXT, font=app_fonts["bold10"], anchor="w", justify=tk.LEFT, wraplength=560, padx=10, pady=4)
    def set_updates_strip(count):
        """A gold strip above the list - same look as the notification banner - while updates are waiting."""
        if not count:
            lbl_updates_strip.pack_forget()
            return
        text = "✨ %d update%s available" % (count, "" if count == 1 else "s")
        if count > 1:
            text += "  -  Ctrl-click or Shift-click to select several, then press Update."
        lbl_updates_strip.config(text=text)
        if not lbl_updates_strip.winfo_manager():
            lbl_updates_strip.pack(fill=tk.X, pady=(0, 4), before=list_frame_apps)
    list_frame_apps = ttk.Frame(tab_apps); list_frame_apps.pack(fill=tk.BOTH, expand=True, pady=5)
    listbox = tk.Listbox(list_frame_apps, height=8, width=50, exportselection=False, selectmode=tk.EXTENDED)
    scroll_apps = ttk.Scrollbar(list_frame_apps, orient=tk.VERTICAL, command=listbox.yview)
    listbox.configure(yscrollcommand=scroll_apps.set)
    scroll_apps.pack(side=tk.RIGHT, fill=tk.Y)
    listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    listbox.bind("<<ListboxSelect>>", update_action_button_state)
    fb = ttk.Frame(tab_apps); fb.pack(fill=tk.X, pady=2)
    btn_update_app = ttk.Button(fb, text="🆙 Update Selected App", command=run_direct_inapp_update, state="disabled"); btn_update_app.pack(side=tk.LEFT)
    ttk.Button(fb, text="❌ Stop Tracking Target", command=run_tracking_removal).pack(side=tk.RIGHT)
    note_row = ttk.Frame(tab_apps); note_row.pack(fill=tk.X, pady=(4, 0))
    btn_restore_hidden = ttk.Button(note_row, text="↩ Restore Hidden Apps", command=restore_hidden_apps, state="disabled")
    btn_restore_hidden.pack(side=tk.RIGHT, padx=(8, 0))
    lbl_scan_note = ttk.Label(note_row, text="", font=app_fonts["italic9"], foreground="#555555", wraplength=380, justify=tk.LEFT)
    lbl_scan_note.pack(side=tk.LEFT, anchor=tk.W)
    note_row.bind("<Configure>", lambda e: lbl_scan_note.config(wraplength=max(160, e.width - btn_restore_hidden.winfo_reqwidth() - 24)))
    secondary_labels.append(lbl_scan_note)
    def update_hidden_note():
        n = len([a for a in system_config["apps"] if a in hidden_apps])
        if n == 0:
            text = "ℹ️ Apps you hide with 'Stop Tracking Target' stay hidden until you click Restore Hidden Apps."
        elif n == 1:
            text = "ℹ️ 1 app is hidden with 'Stop Tracking Target'. Click Restore Hidden Apps to list it again."
        else:
            text = "ℹ️ %d apps are hidden with 'Stop Tracking Target'. Click Restore Hidden Apps to list them again." % n
        lbl_scan_note.config(text=text)
        btn_restore_hidden.config(state="normal" if n else "disabled")
    update_hidden_note()

    ins = ttk.LabelFrame(tab_manage, text=" 📥 Install directly from Flathub ", padding="10"); ins.pack(fill=tk.X, pady=5)
    fbar = ttk.Frame(ins); fbar.pack(fill=tk.X, pady=2)
    direct_install_entry = ttk.Entry(fbar)
    direct_install_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
    direct_install_entry.bind("<Return>", lambda event: direct_system_install())
    search_spinner_label = ttk.Label(fbar, text="", foreground="#00bcff"); search_spinner_label.pack(side=tk.LEFT)
    ttk.Button(fbar, text="📂 Install from File", command=browse_and_install_file).pack(side=tk.RIGHT)
    ttk.Button(fbar, text="🚀 Search & Install", command=direct_system_install).pack(side=tk.RIGHT, padx=(0, 8))
    tip_str = "💡 Operation Tip: Type a name (e.g. 'VLC') or ID (e.g. 'org.videolan.VLC'). The system will search Flathub and prompt you."
    lbl_search_tip = ttk.Label(ins, text=tip_str, font=app_fonts["italic9"], foreground="#555555", wraplength=560, justify=tk.LEFT)
    lbl_search_tip.pack(anchor=tk.W, pady=(6, 2))
    secondary_labels.append(lbl_search_tip)

    uns = ttk.LabelFrame(tab_manage, text=" 🔥 Installed Applications & Purge Hub ", padding="10"); uns.pack(fill=tk.BOTH, expand=True, pady=5)
    list_frame_manage = ttk.Frame(uns); list_frame_manage.pack(fill=tk.BOTH, expand=True, pady=2)
    manage_listbox = tk.Listbox(list_frame_manage, height=5, exportselection=False)
    scroll_manage = ttk.Scrollbar(list_frame_manage, orient=tk.VERTICAL, command=manage_listbox.yview)
    manage_listbox.configure(yscrollcommand=scroll_manage.set)
    scroll_manage.pack(side=tk.RIGHT, fill=tk.Y)
    manage_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    ttk.Button(uns, text="🗑️ Uninstall Selected App from Computer", command=direct_system_uninstall).pack(anchor=tk.E, pady=5)

    aut = ttk.LabelFrame(tab_prefs, text=" ⚙️ Automation Settings ", padding="10"); aut.pack(fill=tk.X, pady=4)
    all_toggle_switches = []
    row_m = ttk.Frame(aut); row_m.pack(fill=tk.X, pady=6)
    ttk.Label(row_m, text="Enable Background Auto App Diagnostics: ", font=app_fonts["body10"]).pack(side=tk.LEFT)
    rule_toggle_widgets = []
    def on_m_toggle(s):
        system_config["auto_scan_enabled"] = s
        save_settings(system_config)
        for w in rule_toggle_widgets: w.set_enabled(s)
    master_enabled = system_config.get("auto_scan_enabled", False)
    master_toggle = ModernToggleSwitch(row_m, command=on_m_toggle, initial_state=master_enabled)
    master_toggle.pack(side=tk.RIGHT)
    all_toggle_switches.append(master_toggle)

    rule_toggle_map = {}
    INTERVAL_RULES = ["Every 1 hour", "Every 3 hours", "Once per day", "Once per week"]
    for ev in ["On boot", "Every 1 hour", "Every 3 hours", "Once per day", "Once per week"]:
        row_e = ttk.Frame(aut); row_e.pack(fill=tk.X, pady=2)
        ttk.Label(row_e, text=f"  Rule: {ev}").pack(side=tk.LEFT)
        def make_cb(e=ev):
            def cb(s):
                system_config.setdefault("scan_intervals", [])
                if s and e not in system_config["scan_intervals"]:
                    system_config["scan_intervals"].append(e)
                elif not s and e in system_config["scan_intervals"]:
                    system_config["scan_intervals"].remove(e)
                if s and e in INTERVAL_RULES:
                    for other in INTERVAL_RULES:
                        if other != e and other in system_config["scan_intervals"]:
                            system_config["scan_intervals"].remove(other)
                            other_widget = rule_toggle_map.get(other)
                            if other_widget:
                                other_widget.state = False
                                other_widget.draw_toggle_element()
                save_settings(system_config)
            return cb
        rule_toggle = ModernToggleSwitch(row_e, command=make_cb(), initial_state=(ev in system_config.get("scan_intervals", ["On boot"])), enabled=master_enabled)
        rule_toggle.pack(side=tk.RIGHT)
        rule_toggle_widgets.append(rule_toggle)
        rule_toggle_map[ev] = rule_toggle
        all_toggle_switches.append(rule_toggle)

    diag = ttk.LabelFrame(tab_tools, text=" 🧪 Diagnostics & Testing ", padding="15"); diag.pack(fill=tk.X, pady=5)
    lbl_diag_desc = ttk.Label(diag, text="Verify the update-notification system is working, without needing a real pending update.", font=app_fonts["body9"], foreground="#555555", wraplength=560, justify=tk.LEFT)
    lbl_diag_desc.pack(anchor=tk.W, pady=(0, 8))
    secondary_labels.append(lbl_diag_desc)
    diag_row = ttk.Frame(diag); diag_row.pack(fill=tk.X)

    def simulate_test_update():
        if not system_config["apps"]:
            messagebox.showinfo("Nothing to test", "No tracked apps yet — run a scan first so there's at least one app to simulate an update for.")
            return
        test_aid = next((a for a in system_config["apps"] if a not in hidden_apps), None)
        if test_aid is None:
            messagebox.showinfo("Nothing to test", "Every tracked app is hidden. Click Restore Hidden Apps to list them again, then try again.")
            return
        cached_updates.add(test_aid)
        refresh_list()
        if icon_instance:
            icon_instance.menu = create_menu_items()
            icon_instance.update_menu()
        trigger_banner_popup(f"Test Event: Simulated update for {system_config['apps'][test_aid]}")

    def clear_test_updates():
        cached_updates.clear()
        cached_updates.update(get_apps_with_updates())
        refresh_list()
        if icon_instance:
            icon_instance.menu = create_menu_items()
            icon_instance.update_menu()
        trigger_banner_popup("Test Event: Cleared simulated updates.")

    ttk.Button(diag_row, text="🧪 Simulate Pending Update", command=simulate_test_update).pack(side=tk.LEFT)
    ttk.Button(diag_row, text="↺ Clear Test Flags", command=clear_test_updates).pack(side=tk.LEFT, padx=(8, 0))

    def show_tray_message(st, auto):
        """One dialog for both the automatic first-run notice and the Tools button."""
        try:
            win = tk.Toplevel(root)
            win.title("System Tray")
            _c = THEME_COLORS["dark"] if system_config.get("dark_mode", False) else THEME_COLORS["light"]
            win.configure(bg=_c["bg"])
            win.resizable(False, False)
            if root.winfo_viewable(): win.transient(root)
            backend = st.get("backend") or "unknown"
            if st["present"] is True:
                head = "✅ System tray found"
                body = "The Flatpak Manager arrow should be showing near your clock.\n\nTray method in use: " + backend
            elif st["present"] is False:
                head = "⚠️ System tray not found"
                body = ("Flatpak Manager lives in your system tray (near the clock) and turns gold when updates are waiting. "
                        "I couldn't find a tray on your panel, so the icon may not be visible.\n\n"
                        "To turn it on:\n" + tray_setup_instructions() + "\n\n"
                        "The app still works without it - use this window, or open Flatpak Manager from your applications menu. "
                        "If you can already see the arrow icon, you can ignore this.")
            else:
                head = "❔ Couldn't check the system tray"
                body = "This desktop didn't let me look for a tray. If you can see the arrow icon near your clock, all is well.\n\nIf not:\n" + tray_setup_instructions()
            ttk.Label(win, text=head, font=app_fonts["bold11"]).pack(anchor=tk.W, padx=18, pady=(16, 6))
            ttk.Label(win, text=body, font=app_fonts["body10"], wraplength=440, justify=tk.LEFT).pack(anchor=tk.W, padx=18)
            dont_ask = tk.BooleanVar(value=False)
            if auto and st["present"] is False:
                ttk.Checkbutton(win, text="Don't remind me again", variable=dont_ask).pack(anchor=tk.W, padx=18, pady=(12, 0))
            def close():
                if auto and dont_ask.get():
                    system_config["tray_hint_dismissed"] = True
                    save_settings(system_config)
                win.destroy()
            ttk.Button(win, text="OK", command=close).pack(anchor=tk.E, padx=18, pady=14)
            win.protocol("WM_DELETE_WINDOW", close)
            win.update_idletasks()
            x = root.winfo_rootx() + max(0, (root.winfo_width() - win.winfo_width()) // 2)
            y = root.winfo_rooty() + max(0, (root.winfo_height() - win.winfo_height()) // 3)
            win.geometry("+%d+%d" % (x, y))
        except tk.TclError:
            pass

    def check_tray_now():
        threading.Thread(target=lambda: (lambda st: root.after(0, lambda: show_tray_message(st, False)))(tray_status()), daemon=True).start()

    diag_row2 = ttk.Frame(diag); diag_row2.pack(fill=tk.X, pady=(8, 0))
    ttk.Button(diag_row2, text="🔍 Check System Tray", command=check_tray_now).pack(side=tk.LEFT)

    def run_maintenance_command(label, cmd):
        if messagebox.askyesno("Confirm", f"Run '{label}'?\n\nCommand: {cmd}"):
            handle = launch_tracked_command(cmd)
            if not handle:
                messagebox.showerror("No Terminal Found", "Couldn't find a terminal emulator on this system to run this command.")
                return
            track_operation(handle, label, success_text=f"Event: {label} completed.")

    maint = ttk.LabelFrame(tab_tools, text=" 🛠️ Flatpak Maintenance ", padding="15"); maint.pack(fill=tk.X, pady=5)
    lbl_maint_desc = ttk.Label(maint, text="Common upkeep tasks. Each opens a terminal window so you can watch it run.", font=app_fonts["body9"], foreground="#555555", wraplength=560, justify=tk.LEFT)
    lbl_maint_desc.pack(anchor=tk.W, pady=(0, 8))
    secondary_labels.append(lbl_maint_desc)
    ttk.Button(maint, text="🧹 Remove Unused Runtimes & Dependencies", width=45, command=lambda: run_maintenance_command("Remove Unused Runtimes & Dependencies", "flatpak uninstall --unused -y")).pack(anchor=tk.W, pady=4)
    ttk.Button(maint, text="🔧 Repair Flatpak Installation", width=45, command=lambda: run_maintenance_command("Repair Flatpak Installation", "flatpak repair")).pack(anchor=tk.W, pady=4)
    ttk.Button(maint, text="🔄 Refresh App Metadata & Icons", width=45, command=lambda: run_maintenance_command("Refresh App Metadata & Icons", "flatpak update --appstream")).pack(anchor=tk.W, pady=4)

    startsec = ttk.LabelFrame(tab_prefs, text=" 🚀 Startup ", padding="8"); startsec.pack(fill=tk.X, pady=4)
    row_start = ttk.Frame(startsec); row_start.pack(fill=tk.X)
    ttk.Label(row_start, text="Start Flatpak Manager when I log in: ", font=app_fonts["body10"]).pack(side=tk.LEFT)
    def on_autostart_toggle(s):
        if not set_autostart(s):
            messagebox.showerror("Start at login", "Couldn't change the login startup setting (the autostart folder isn't writable).")
            autostart_toggle.state = not s
            autostart_toggle.draw_toggle_element()
            return
        try:
            if icon_instance: icon_instance.update_menu()
        except Exception:
            pass
    autostart_toggle = ModernToggleSwitch(row_start, command=on_autostart_toggle, initial_state=autostart_enabled())
    autostart_toggle.pack(side=tk.RIGHT)
    all_toggle_switches.append(autostart_toggle)
    lbl_start_desc = ttk.Label(startsec, text="Starts quietly in the system tray (the window stays closed), so the arrow can turn gold when updates arrive.", font=app_fonts["body9"], foreground="#555555", wraplength=520, justify=tk.LEFT)
    lbl_start_desc.pack(anchor=tk.W, pady=(4, 0))
    secondary_labels.append(lbl_start_desc)
    def sync_autostart_switch():
        def apply():
            autostart_toggle.state = autostart_enabled()
            autostart_toggle.draw_toggle_element()
        root.after(0, apply)
    _autostart_ui_sync = sync_autostart_switch

    appearance = ttk.LabelFrame(tab_prefs, text=" 🎨 Appearance ", padding="8"); appearance.pack(fill=tk.X, pady=4)
    row_theme = ttk.Frame(appearance); row_theme.pack(fill=tk.X, pady=2)
    ttk.Label(row_theme, text="Dark Mode: ", font=app_fonts["body10"]).pack(side=tk.LEFT)
    def on_theme_toggle(s):
        system_config["dark_mode"] = s
        save_settings(system_config)
        apply_theme(s)
    theme_toggle = ModernToggleSwitch(row_theme, command=on_theme_toggle, initial_state=system_config.get("dark_mode", False))
    theme_toggle.pack(side=tk.RIGHT)
    all_toggle_switches.append(theme_toggle)

    fontsec = ttk.LabelFrame(tab_prefs, text=" 🔤 Font Size ", padding="8"); fontsec.pack(fill=tk.X, pady=4)
    font_row = ttk.Frame(fontsec); font_row.pack(fill=tk.X)
    ttk.Label(font_row, text="Text Size: ", font=app_fonts["body10"]).pack(side=tk.LEFT)
    btn_font_minus = ttk.Button(font_row, text="A-", width=4, command=lambda: apply_font_scale(system_config.get("font_scale", 0) - 1))
    btn_font_minus.pack(side=tk.LEFT, padx=(10, 4))
    lbl_font_scale_display = ttk.Label(font_row, text="Normal", font=app_fonts["body10"], width=10, anchor="center")
    lbl_font_scale_display.pack(side=tk.LEFT)
    btn_font_plus = ttk.Button(font_row, text="A+", width=4, command=lambda: apply_font_scale(system_config.get("font_scale", 0) + 1))
    btn_font_plus.pack(side=tk.LEFT, padx=(4, 0))

    soundsec = ttk.LabelFrame(tab_prefs, text=" 🔔 Sounds ", padding="8"); soundsec.pack(fill=tk.X, pady=4)
    row_sound = ttk.Frame(soundsec); row_sound.pack(fill=tk.X)
    ttk.Label(row_sound, text="Sound Notifications: ", font=app_fonts["body10"]).pack(side=tk.LEFT)
    def on_sound_toggle(s):
        system_config["sounds_enabled"] = s
        save_settings(system_config)
    sound_toggle = ModernToggleSwitch(row_sound, command=on_sound_toggle, initial_state=system_config.get("sounds_enabled", False))
    sound_toggle.pack(side=tk.RIGHT)
    all_toggle_switches.append(sound_toggle)
    ttk.Button(row_sound, text="🔔 Test Sound", command=play_notification_sound).pack(side=tk.RIGHT, padx=(0, 12))
    lbl_sound_desc = ttk.Label(soundsec, text="Plays a short sound when a new app update is found. Off by default.", font=app_fonts["body9"], foreground="#555555", wraplength=520, justify=tk.LEFT)
    lbl_sound_desc.pack(anchor=tk.W, pady=(4, 0))
    secondary_labels.append(lbl_sound_desc)

    lbl_title = ttk.Label(tab_info, text="Application Information Center", font=app_fonts["bold11"])
    lbl_title.pack(anchor=tk.W, pady=(0, 5))
    lbl_desc = ttk.Label(tab_info, text="Select a category below to open licensing logs and credits.", font=app_fonts["body9"], wraplength=580, justify=tk.LEFT)
    lbl_desc.pack(anchor=tk.W, pady=(0, 20))

    def launch_document_window(window_title, data_key):
        doc_win = tk.Toplevel(root)
        doc_win.title(window_title)
        doc_win.geometry("540x450")
        doc_win.resizable(False, False)
        doc_win.transient(root)
        doc_win.grab_set()
        _c = THEME_COLORS["dark"] if system_config.get("dark_mode", False) else THEME_COLORS["light"]
        doc_win.configure(bg=_c["bg"])
        cv = tk.Canvas(doc_win, highlightthickness=0, bg=_c["bg"])
        scroll = ttk.Scrollbar(doc_win, orient=tk.VERTICAL, command=cv.yview)
        sf = ttk.Frame(cv, padding=15)
        sf.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
        cv.create_window((0, 0), window=sf, anchor="nw")
        cv.configure(yscrollcommand=scroll.set)
        lbl = ttk.Label(sf, text=LEGAL_DATA[data_key], font=app_fonts["mono10"], justify=tk.LEFT, wraplength=480)
        lbl.pack(fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        def _doc_scroll(event):
            if event.num == 4: step = -1
            elif event.num == 5: step = 1
            else: step = -1 if event.delta > 0 else 1
            cv.yview_scroll(step * 3, "units")
        for _seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            doc_win.bind(_seq, _doc_scroll)
        doc_win.bind("<Up>", lambda e: cv.yview_scroll(-2, "units"))
        doc_win.bind("<Down>", lambda e: cv.yview_scroll(2, "units"))
        doc_win.bind("<Prior>", lambda e: cv.yview_scroll(-1, "pages"))
        doc_win.bind("<Next>", lambda e: cv.yview_scroll(1, "pages"))
        doc_win.bind("<Home>", lambda e: cv.yview_moveto(0.0))
        doc_win.bind("<End>", lambda e: cv.yview_moveto(1.0))
        cv.pack(fill=tk.BOTH, expand=True)

    btn_grid_frame = ttk.Frame(tab_info)
    btn_grid_frame.pack(fill=tk.X, anchor=tk.W)
    ttk.Button(btn_grid_frame, text="📄 End User License Agreement (EULA)", width=45, command=lambda: launch_document_window("End User License Agreement (EULA)", "eula")).pack(anchor=tk.W, pady=4)
    ttk.Button(btn_grid_frame, text="📜 Upstream Acknowledgements", width=45, command=lambda: launch_document_window("Upstream Acknowledgements", "upstream")).pack(anchor=tk.W, pady=4)
    ttk.Button(btn_grid_frame, text="❓ User Operation Help Guide", width=45, command=lambda: launch_document_window("User Operation Help Guide", "help")).pack(anchor=tk.W, pady=4)
    ttk.Button(btn_grid_frame, text="🎖️ About Flatpak Manager", width=45, command=lambda: launch_document_window("About Flatpak Manager", "about")).pack(anchor=tk.W, pady=4)

    links_frame = ttk.LabelFrame(tab_info, text=" 🔗 Support & Links ", padding="15"); links_frame.pack(fill=tk.X, pady=(15, 5))
    links_row = ttk.Frame(links_frame); links_row.pack(fill=tk.X)
    ttk.Button(links_row, text="⭐ View on GitHub", command=lambda: _open_link_quietly("https://github.com/Classic-Gizmo")).pack(side=tk.LEFT)
    ttk.Button(links_row, text="🌐 Website", command=lambda: _open_link_quietly("https://classicgizmo.com/")).pack(side=tk.LEFT, padx=(8, 0))
    ttk.Button(links_row, text="☕ Buy Me a Coffee", command=lambda: _open_link_quietly("https://buymeacoffee.com/classicgizmo")).pack(side=tk.LEFT, padx=(8, 0))
    links_row2 = ttk.Frame(links_frame); links_row2.pack(fill=tk.X, pady=(8, 0))
    ttk.Button(links_row2, text="💼 Licensing & Pricing", command=lambda: _open_link_quietly(LICENSE_INFO_URL)).pack(side=tk.LEFT)

    def apply_font_scale(scale):
        scale = max(-2, min(2, scale))
        system_config["font_scale"] = scale
        save_settings(system_config)
        for role, spec in FONT_ROLE_SPECS.items():
            app_fonts[role].configure(size=spec["size"] + scale)
        for fname, base_size in base_tk_font_sizes.items():
            try: tkfont.nametofont(fname).configure(size=base_size + scale)
            except tk.TclError: pass
        scale_labels = {-2: "Smallest", -1: "Smaller", 0: "Normal", 1: "Larger", 2: "Largest"}
        lbl_font_scale_display.config(text=scale_labels[scale])
        btn_font_minus.config(state=("disabled" if scale <= -2 else "normal"))
        btn_font_plus.config(state=("disabled" if scale >= 2 else "normal"))

    def apply_theme(dark):
        colors = THEME_COLORS["dark"] if dark else THEME_COLORS["light"]
        style = ttk.Style()
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure(".", background=colors["bg"], foreground=colors["fg"])
        style.configure("TFrame", background=colors["bg"])
        style.configure("TLabel", background=colors["bg"], foreground=colors["fg"])
        style.configure("TButton", background=colors["widget_bg"], foreground=colors["fg"])
        style.map("TButton", background=[("active", colors["select_bg"])])
        style.configure("TLabelframe", background=colors["bg"], foreground=colors["fg"])
        style.configure("TLabelframe.Label", background=colors["bg"], foreground=colors["fg"])
        style.configure("TNotebook", background=colors["bg"])
        style.configure("TNotebook.Tab", background=colors["widget_bg"], foreground=colors["fg"])
        style.map("TNotebook.Tab", background=[("selected", colors["bg"])], foreground=[("selected", colors["fg"])])
        style.configure("TEntry", fieldbackground=colors["widget_bg"], foreground=colors["fg"])
        style.configure("TCheckbutton", background=colors["bg"], foreground=colors["fg"], indicatorbackground=colors["widget_bg"], indicatorforeground=colors["fg"])
        style.map("TCheckbutton", background=[("active", colors["bg"])], indicatorbackground=[("pressed", colors["select_bg"]), ("active", colors["widget_bg"])])
        root.configure(bg=colors["bg"])
        prefs_canvas.configure(bg=colors["bg"])
        for lb in (listbox, manage_listbox):
            lb.configure(bg=colors["widget_bg"], fg=colors["fg"], selectbackground=colors["select_bg"], highlightbackground=colors["bg"], highlightcolor=colors["bg"])
        for tog in all_toggle_switches:
            tog.configure(bg=colors["bg"])
        for lbl in secondary_labels:
            lbl.configure(foreground=colors["secondary_fg"])

    root.after(500, lambda: [refresh_list(), refresh_system_installed_list()])
    _ui_refresh_hook = lambda: root.after(0, lambda: [refresh_list(), refresh_system_installed_list()])

    def auto_tray_check(attempt=1):
        if system_config.get("tray_hint_dismissed"):
            return
        def worker():
            st = tray_status()
            def done():
                if st["present"] is not False:
                    return                       # found, or can't tell: stay quiet
                if attempt < 3:
                    root.after(8000, lambda: auto_tray_check(attempt + 1))   # panel may still be starting
                else:
                    if start_hidden and not root.winfo_viewable():
                        bring_window_to_front()      # no tray AND no window would leave the app invisible
                    show_tray_message(st, True)
            root.after(0, done)
        threading.Thread(target=worker, daemon=True).start()
    root.after(8000, auto_tray_check)
    if pending_file:
        root.after(900, lambda: [bring_window_to_front(), install_from_file(pending_file)])
    if startup_notice:
        root.after(900, lambda: [bring_window_to_front(), messagebox.showerror("Flatpak Manager", startup_notice)])

    def bring_window_to_front():
        try:
            root.deiconify(); root.lift(); root.focus_force()
            root.attributes("-topmost", True)
            root.after(400, lambda: root.attributes("-topmost", False))
        except tk.TclError:
            pass

    def handle_ipc_message(msg):
        bring_window_to_front()
        if msg.get("cmd") == "install":
            path = msg.get("path")
            if isinstance(path, str) and os.path.isfile(path):
                install_from_file(path)
        elif msg.get("cmd") == "notice" and isinstance(msg.get("text"), str):
            messagebox.showerror("Flatpak Manager", msg["text"][:1500])

    if ipc_server is not None:
        threading.Thread(target=ipc_listen_loop, args=(ipc_server, lambda m: root.after(0, lambda: handle_ipc_message(m))), daemon=True).start()
    lbl_footer_credit = ttk.Label(footer_frame, text="© Flatpak Manager by Classic Gizmo", foreground="#555555", font=app_fonts["body9"])
    lbl_footer_credit.pack(side=tk.LEFT, padx=15, pady=10)
    secondary_labels.append(lbl_footer_credit)
    ttk.Button(footer_frame, text="Close Window", command=lambda: root.withdraw()).pack(side=tk.RIGHT, padx=15, pady=10)
    apply_theme(system_config.get("dark_mode", False))
    apply_font_scale(system_config.get("font_scale", 0))
    root.unbind_all("<Tab>")
    threading.Thread(target=background_orchestrator, kwargs={"initial_delay": 3 if start_hidden else 0}, daemon=True).start()
    root.mainloop()

def resolve_pending_install_source(arg):
    """Turns a launch argument into something installable. Returns (path, error):
    exactly one of them is set (both None for no argument). Accepts a local
    .flatpak/.flatpakref path, a file:// URI, or a flatpak+https:// link from
    Flathub's website 'Install' button - which is downloaded and checked first.
    A problem comes back as a plain-English message instead of silently doing nothing."""
    if not arg:
        return None, None
    if arg.startswith("file://"):
        arg = urllib.parse.unquote(arg[len("file://"):])
    if arg.startswith("flatpak+https://") or arg.startswith("flatpak+http://"):
        real_url = arg[len("flatpak+"):]
        host = urllib.parse.urlparse(real_url).hostname or "that website"
        try:
            req = urllib.request.Request(real_url, headers={"User-Agent": "FlatpakManager/%s (+https://classicgizmo.com)" % APP_VERSION})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = resp.read(1024 * 1024)
            text = data.decode("utf-8", "replace")
            if "[Flatpak Ref]" not in text:
                if "[Flatpak Repo]" in text:
                    return None, "That link is a Flatpak repository (an app store), not an app, so there is nothing for Flatpak Manager to install from it."
                return None, "The link from %s didn't give back a Flatpak install file, so nothing was installed." % host
            fd, tmp_path = tempfile.mkstemp(prefix="flatpak_manager_", suffix=".flatpakref")
            with os.fdopen(fd, "wb") as out:
                out.write(data)
            return tmp_path, None
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None, "%s doesn't have an install file at that address (error 404). The app may have been removed or renamed." % host
            if e.code in (401, 403):
                return None, "%s refused the request (error %d), so the install file couldn't be fetched." % (host, e.code)
            return None, "%s answered with an error (%d %s), so the install file couldn't be fetched." % (host, e.code, e.reason)
        except (socket.timeout, TimeoutError):
            return None, "%s took too long to answer. Check your internet connection and try the Install button again." % host
        except urllib.error.URLError as e:
            return None, "Couldn't reach %s. Check your internet connection and try again.\n\n(%s)" % (host, e.reason)
        except Exception as e:
            return None, "The install link couldn't be fetched from %s.\n\n(%s: %s)" % (host, type(e).__name__, e)
    if os.path.isfile(arg):
        return arg, None
    return None, "That file couldn't be found:\n%s" % arg

def describe_install_file(filepath):
    """Plain-English text for the confirmation prompt: which app, and where it comes from."""
    ref = None
    try:
        with open(filepath, "rb") as f:
            text = f.read(65536).decode("utf-8", "replace")
        if "[Flatpak Ref]" in text:
            cp = configparser.ConfigParser(interpolation=None, strict=False)
            cp.read_string(text)
            ref = cp["Flatpak Ref"]
    except Exception:
        ref = None
    if ref is None:
        return "Install this Flatpak file?\n\n%s\n\n(%s)\n\nIt will be installed in a terminal window so you can watch the progress." % (os.path.basename(filepath), filepath)
    app_id = (ref.get("name") or "").strip()
    title = (ref.get("title") or "").strip()
    if app_id and (not title or title.lower().startswith(app_id.lower())):
        title = app_id.rsplit(".", 1)[-1] or app_id        # Flathub titles files "<app id> from flathub"; "Defuse" reads better
    title = title or app_id or os.path.basename(filepath)
    headline = "Install \u201c%s\u201d" % title + (" (%s)?" % app_id if app_id and app_id != title else "?")
    src_host = urllib.parse.urlparse((ref.get("url") or "").strip()).hostname
    if not src_host:
        source = "Source: not stated in the file"
    elif src_host == "flathub.org" or src_host.endswith(".flathub.org"):
        source = "Source: Flathub (%s)" % src_host
    else:
        source = "Source: %s\nThis is NOT Flathub - only continue if you trust it." % src_host
    return "%s\n\n%s\n\nIt will be installed in a terminal window so you can watch the progress." % (headline, source)

def _single_instance_paths():
    """Lock + socket locations: XDG_RUNTIME_DIR (private to the user) when
    available, otherwise a private folder in the user's cache directory."""
    try:
        runtime = os.environ.get("XDG_RUNTIME_DIR")
        if runtime and os.path.isdir(runtime):
            base = runtime
            shared = os.path.join(runtime, "app", FLATPAK_APP_ID)
            if IN_FLATPAK and os.path.isdir(shared):         # each `flatpak run` gets its own /run/user/UID; this folder is the one they share
                base = shared
        else:
            base = os.path.expanduser("~/.cache/flatpak-manager")
            os.makedirs(base, mode=0o700, exist_ok=True)
        sock = os.path.join(base, "flatpak_manager.sock")
        if len(os.fsencode(sock)) > 100:
            return None
        return os.path.join(base, "flatpak_manager.lock"), sock
    except OSError:
        return None

def _send_to_running_instance(sock_path, message):
    """Hands a message to the already-running copy. Retries briefly in case it
    is still in the middle of starting up."""
    for _ in range(40):
        cli = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        cli.settimeout(2)
        try:
            cli.connect(sock_path)
            cli.sendall(message.encode("utf-8"))
            return True
        except (FileNotFoundError, ConnectionRefusedError, socket.timeout):
            time.sleep(0.1)
        except OSError:
            return False
        finally:
            cli.close()
    return False

def acquire_single_instance(message):
    """Makes sure only one copy of the app runs per user.
    Returns ("primary", server_socket_or_None), ("already_running", delivered_bool)
    or ("unavailable", None) if the guard itself can't be set up, in which case
    the app just starts normally rather than refusing to run.
    The lock is held by the operating system for as long as the process lives,
    so a crash or a tray Quit can never leave behind a stale lock."""
    global _instance_lock_fd, _instance_socket_path
    paths = _single_instance_paths()
    if paths is None:
        return ("unavailable", None)
    lock_path, sock_path = paths
    try:
        fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    except OSError:
        return ("unavailable", None)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as e:
        os.close(fd)
        if e.errno in (errno.EWOULDBLOCK, errno.EAGAIN):
            return ("already_running", _send_to_running_instance(sock_path, message))
        return ("unavailable", None)
    _instance_lock_fd = fd
    server = None
    try:
        try: os.unlink(sock_path)
        except FileNotFoundError: pass
        server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        server.bind(sock_path)
        os.chmod(sock_path, 0o600)
        server.listen(8)
        _instance_socket_path = sock_path
    except OSError:
        if server: server.close()
        server = None
    return ("primary", server)

def ipc_listen_loop(server, on_message):
    """Runs in a background thread inside the primary copy, receiving small
    JSON messages ({"cmd": "show"} or {"cmd": "install", "path": ...})."""
    while True:
        try:
            conn, _ = server.accept()
        except OSError:
            return
        try:
            conn.settimeout(2)
            data = b""
            while len(data) < 8192 and not data.endswith(b"\n"):
                chunk = conn.recv(1024)
                if not chunk: break
                data += chunk
            msg = json.loads(data.decode("utf-8", "replace"))
            if isinstance(msg, dict) and msg.get("cmd") in ("show", "install", "notice"):
                on_message(msg)
        except Exception:
            pass
        finally:
            conn.close()

def run_self_check():
    """`flatpak_manager.py --check`: confirms everything needed is present without
    opening a window. install.sh uses this to verify its own work."""
    backend = tray_backend_name() or "unknown"
    print("Flatpak Manager %s" % APP_VERSION)
    print("  Tk for Python .......... OK")
    print("  Pillow ................. OK")
    if pystray is None:
        print("  Tray support (pystray) . not tested here (no desktop session) - it is checked when the app starts")
        backend = "unknown"
    else:
        print("  Tray support (pystray) . OK (method: %s)" % backend)
    if backend in ("gtk", "xorg"):
        print("      note: this method only shows in a classic system tray. For wider desktop support install")
        print("      python3-gi, gir1.2-gtk-3.0 and gir1.2-ayatanaappindicator3-0.1 (see README.md).")
    fp = host_which("flatpak")
    if IN_FLATPAK:
        print("  sandbox ................ running inside a Flatpak (host commands go through flatpak-spawn)")
    print("  flatpak ................ " + (fp if fp else "NOT FOUND (the app will offer to install it)"))
    return 0

def main():
    args = sys.argv[1:]
    if "--check" in args:
        sys.exit(run_self_check())
    positional = [a for a in args if not a.startswith("-")]
    pending_file, link_error = resolve_pending_install_source(positional[0]) if positional else (None, None)
    if link_error:
        print("[Flatpak Manager] " + link_error.replace("\n\n", " ").replace("\n", " "), file=sys.stderr)
    start_hidden = "--background" in args and not pending_file and not link_error
    if pending_file:
        payload = {"cmd": "install", "path": pending_file}
    elif link_error:
        payload = {"cmd": "notice", "text": link_error[:1500]}
    else:
        payload = {"cmd": "noop"} if start_hidden else {"cmd": "show"}
    status, extra = acquire_single_instance(json.dumps(payload) + "\n")
    if status == "already_running":
        if start_hidden:
            return                      # a login-time launch while it is already running: nothing to do
        if extra:
            print("[Flatpak Manager] Already running - brought the existing window to the front.")
        else:
            print("[Flatpak Manager] Already running, but it couldn't be reached. Use its tray icon to open the window.")
        return
    try:
        show_settings_window(pending_file, extra if status == "primary" else None, start_hidden, link_error)
    except tk.TclError as e:
        if "display" in str(e).lower():
            print("[Flatpak Manager] No graphical display found - this app needs to run inside your desktop session.", file=sys.stderr)
            sys.exit(1)
        raise
if __name__ == "__main__": main()
